﻿/* *****
 * MARGINAL IMPACT FACTORS REPOSITORY PROJECT
 * 
 * This script aggregates the hourly demand by nerc and writes out the results as .csv
 *
 * CHANGE LOG:
 * 03/2016 (Nat Horner) - Created.
 */

/* Aggregate hourly by NERC region */
DROP TABLE IF EXISTS demand_agg_by_nerc;
SELECT ts, nerc, sum(demand) as demand_mwh
INTO TEMP TABLE demand_agg_by_nerc
FROM ferc_demand_hourly as d
LEFT JOIN (SELECT respondent_id, nerc, drop FROM ferc_geography) as g
	ON d.respondent_id=g.respondent_id
WHERE g.drop=FALSE AND (report_yr = 2013 OR report_yr = 2014)
GROUP BY ts, nerc
ORDER BY ts, nerc;

SET @outfile='C:\\Marginal emissions factor data\\Regression Input\\demand_agg_by_nerc2014.csv';
COPY(SELECT * FROM demand_agg_by_nerc) TO '@outfile' (format csv, header);
