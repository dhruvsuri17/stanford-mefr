﻿/* *****
 * MARGINAL IMPACT FACTORS REPOSITORY PROJECT
 * 
 * This script imports FERC714 hourly demand data into the database.
 *
 * CHANGE LOG:
 * --/---- (Kyle Siler-Evans) - Original code
 * 01/2016 (Nat Horner) - General cleanup & commenting
 */

/* Define file locations */
SET @dir_raw='C:\\Marginal emissions factor data\\FERC714\\download\\'; -- location of downloaded FERC 714 data
SET @file_demand=@dir_raw + 'Part 3 Schedule 2 - Planning Area Hourly Demand.csv';
SET @file_respid=@dir_raw + 'Respondent IDs.csv';

DROP TABLE IF EXISTS fercdemand;
CREATE TEMP TABLE fercdemand(
	respondent_id int null,
	report_yr int null,
	report_prd int null,
	spplmnt_num int null,
	row_num int null,
	plan_date date,
	timezone varchar(255) null, 
	hour01 decimal null,
	hour02 decimal null,
	hour03 decimal null,
	hour04 decimal null,
	hour05 decimal null,
	hour06 decimal null,
	hour07 decimal null,
	hour08 decimal null,
	hour09 decimal null,
	hour10 decimal null,
	hour11 decimal null,
	hour12 decimal null,
	hour13 decimal null,
	hour14 decimal null,
	hour15 decimal null,
	hour16 decimal null,
	hour17 decimal null,
	hour18 decimal null,
	hour19 decimal null,
	hour20 decimal null,
	hour21 decimal null,
	hour22 decimal null,
	hour23 decimal null,
	hour24 decimal null,
	hour25 decimal null,

	timezone_f varchar(255) null, 
	hour01_f decimal null,
	hour02_f decimal null,
	hour03_f decimal null,
	hour04_f decimal null,
	hour05_f decimal null,
	hour06_f decimal null,
	hour07_f decimal null,
	hour08_f decimal null,
	hour09_f decimal null,
	hour10_f decimal null,
	hour11_f decimal null,
	hour12_f decimal null,
	hour13_f decimal null,
	hour14_f decimal null,
	hour15_f decimal null,
	hour16_f decimal null,
	hour17_f decimal null,
	hour18_f decimal null,
	hour19_f decimal null,
	hour20_f decimal null,
	hour21_f decimal null,
	hour22_f decimal null,
	hour23_f decimal null,
	hour24_f decimal null,
	hour25_f decimal null
);

COPY FERCDemand FROM '@file_demand' CSV HEADER;

/* Convert from wide to long format */

DROP TABLE ferc_demand_hourly;

SELECT * into ferc_demand_hourly FROM (
	select respondent_id, report_yr, timezone, plan_date, 1 as hr, hour01 AS Demand, hour01_f AS hr_f
	from fercdemand 
union
	select respondent_id, report_yr, timezone, plan_date, 2 as hr, hour02 AS Demand, hour02_f
	from fercdemand 
union
	select respondent_id, report_yr, timezone, plan_date, 3 as hr, hour03 AS Demand, hour03_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 4 as hr, hour04 AS Demand, hour04_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 5 as hr, hour05 AS Demand, hour05_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 6 as hr, hour06 AS Demand, hour06_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 7 as hr, hour07 AS Demand, hour07_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 8 as hr, hour08 AS Demand, hour08_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 9 as hr, hour09 AS Demand, hour09_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 10 as hr, hour10 AS Demand, hour10_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 11 as hr, hour11 AS Demand, hour11_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 12 as hr, hour12 AS Demand, hour12_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 13 as hr, hour13 AS Demand, hour13_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 14 as hr, hour14 AS Demand, hour14_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 15 as hr, hour15 AS Demand, hour15_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 16 as hr, hour16 AS Demand, hour16_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 17 as hr, hour17 AS Demand, hour17_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 18 as hr, hour18 AS Demand, hour18_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 19 as hr, hour19 AS Demand, hour19_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 20 as hr, hour20 AS Demand, hour20_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 21 as hr, hour21 AS Demand, hour21_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 22 as hr, hour22 AS Demand, hour22_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 23 as hr, hour23 AS Demand, hour23_f
	from fercdemand
union
	select respondent_id, report_yr, timezone, plan_date, 24 as hr, hour24 AS Demand, hour24_f
	from fercdemand
/* Hour 25 is not used consistently: some BAs use it to report the total gen, which causes double counting, so do not use. */

) AS q;



/* Respondent ID */

DROP TABLE ferc_respondents;
CREATE TABLE ferc_respondents (
	respondent_id int null,
	respondent_name varchar(255),
	eia_code int
);
COPY ferc_respondents FROM '@file_respid' CSV header;


