﻿/* *****
 * MARGINAL IMPACT FACTORS REPOSITORY PROJECT
 * 
 * This script imports the FERC BA-NERC region mappings into the database.  The input file
 * needs to be generated manually from the list of FERC BAs, since some overlap.  Also creates
 * annual demand by NERC region to compare against yearly values reported by EIA.
 *
 * CHANGE LOG:
 * 01/2016 (Nat Horner) - created
 */

DROP TABLE ferc_geography;

CREATE TABLE ferc_geography (
respondent_id int,
respondent_name varchar(80),
tz varchar(10),
nerc varchar(6),
egrid varchar(6),
isorto varchar(10),
drop boolean
);

SET @dir_ferc714='C:\\Marginal emissions factor data\\FERC714\\BA_mappings\\';

SET @FromFile=@dir_ferc714 + 'update_2014.csv';
COPY ferc_geography FROM '@FromFile' CSV header;

-- Standardize ERCOT to TRE
UPDATE ferc_geography SET nerc='TRE' WHERE nerc='ERCOT';

/* NERC region totals 
   Compare to EIA totals reported on Form 411 */
DROP TABLE IF EXISTS ferc_yearly_demand;

SELECT report_yr, nerc, sum(demand) as demand INTO ferc_yearly_demand
FROM ferc_demand_hourly as d
JOIN ferc_geography AS g ON g.respondent_id = d.respondent_id
WHERE drop=FALSE
GROUP BY report_yr, nerc
ORDER BY report_yr, nerc;

/* Query to compare with EIA 411 data: */
SELECT report_yr, nerc, demand/1000 AS demand FROM ferc_yearly_demand;

/* Normalize Timezones */
-- Use existing time zone data to create a time zone mapping in ferc_geography
UPDATE ferc_demand_hourly AS d
SET timezone = sub.tz
FROM (SELECT respondent_id, MAX(timezone) AS tz FROM ferc_demand_hourly
	GROUP BY respondent_id) AS sub
WHERE d.timezone = '   ' AND d.respondent_id=sub.respondent_id;

-- For those time zones that are still empty, use the ferc geography table (which has timezones populated manually)
UPDATE ferc_demand_hourly AS d
SET timezone = g.tz
FROM (SELECT respondent_id, tz FROM ferc_geography) AS g
WHERE d.timezone = '   ' AND d.respondent_id=g.respondent_id;

/* Now, harmonize the various time zone codes to:
	EPT - Eastern Prevailing Time
	CPT - Central Prevailing Time
	MTP - Mountain Prevailing Time
	PPT - Pacific Prevailing Time
 IMPORTANT: The following mappings are manually generated after investigating
 the current time zone mix in the FERC data.  They may not apply to new data. */
-- ERCOT & SPP are entirely in CPT
UPDATE ferc_demand_hourly AS d
SET timezone='CPT' 
FROM ferc_geography AS g
WHERE d.respondent_id=g.respondent_id AND g.nerc IN ('ERCOT', 'SPP');

-- FRCC & NPCC are entirely in EPT
UPDATE ferc_demand_hourly AS d
SET timezone='EPT' 
FROM ferc_geography AS g
WHERE d.respondent_id=g.respondent_id AND g.nerc IN ('FRCC', 'NPCC');

-- Standardize codes
UPDATE ferc_demand_hourly
SET timezone='EPT' 
WHERE timezone ~* '^e';

UPDATE ferc_demand_hourly
SET timezone='CPT' 
WHERE timezone ~* '^c';

UPDATE ferc_demand_hourly
SET timezone='MPT' 
WHERE timezone ~* '^m';

UPDATE ferc_demand_hourly
SET timezone='PPT' 
WHERE timezone ~* '^p';

-- Tacoma has a series of numeric TZ for some reason
UPDATE ferc_demand_hourly
SET timezone='PPT'
WHERE respondent_id = 139;

-- Other miscellaneous updates
UPDATE ferc_demand_hourly
SET timezone='CPT'
WHERE timezone=' CS' OR timezone=' CD';

-- Drop Alaska and Hawaii
DELETE FROM ferc_demand_hourly WHERE timezone IN ('AKS', 'AKD', 'AST', 'ADT', 'HST');

-- Get standard timezone for respondents reporting 'DST' as timezone
UPDATE ferc_demand_hourly AS d
SET timezone = sub.timezone
FROM (SELECT DISTINCT timezone, respondent_id FROM ferc_demand_hourly WHERE timezone<>'DST') as sub
WHERE d.timezone = 'DST' AND d.respondent_id = sub.respondent_id;

-- Remove respondent id 2 (unknown)
DELETE FROM ferc_demand_hourly WHERE respondent_id=2;

-- Add new timezone mappings to ferc_geography
UPDATE ferc_geography AS g
SET tz = d.timezone
FROM (SELECT DISTINCT respondent_id, timezone FROM ferc_demand_hourly) as d
WHERE g.respondent_id = d.respondent_id;

/* CONVERT TO ABSOLUTE TIME */

-- First, drop hour 25; it is used inconsistently (Should have already happened on import)
DELETE FROM ferc_demand_hourly WHERE hr=25;

-- Timestamps use hr 0-23; data uses 1-24; shift back 1 hr
UPDATE ferc_demand_hourly SET hr = hr-1;

-- Convert to timestamps
ALTER TABLE ferc_demand_hourly ADD COLUMN ts timestamp without time zone;
UPDATE ferc_demand_hourly SET ts = plan_date + (hr || ' hours')::interval;

/* Shift hours in each time zone before aggregating.
	EPT = no shift
	CPT = +1 (Hour 1 CPT --> Hour 2 EPT)
	MPT = +2
	PPT = +3 */
UPDATE ferc_demand_hourly SET ts = ts + INTERVAL '1 hour' WHERE timezone='CPT';
UPDATE ferc_demand_hourly SET ts = ts + INTERVAL '2 hours' WHERE timezone='MPT';
UPDATE ferc_demand_hourly SET ts = ts + INTERVAL '3 hours' WHERE timezone='PPT';

-- Remove unneeded columns
ALTER TABLE ferc_demand_hourly DROP timezone, DROP plan_date, 
	DROP hr, DROP hr_f;

-- Due to TZ shift, first 3 hours and last 3 hours only include partial demand; drop them.
DELETE FROM ferc_demand_hourly WHERE ts < 
	(SELECT MIN(ts) FROM ferc_demand_hourly) + INTERVAL '3 hours';
DELETE FROM ferc_demand_hourly WHERE ts > 
	(SELECT MAX(ts) FROM ferc_demand_hourly) - INTERVAL '3 hours';

-- CREATE INDEX
CREATE INDEX idx_demand ON ferc_demand_hourly (respondent_id, ts, demand);
