﻿/* *****
 * MARGINAL IMPACT FACTORS REPOSITORY PROJECT
 * 
 * This script imports individual csv CEMS files into the SQL database.
 *
 * CHANGE LOG:
 * --/---- (Kyle Siler-Evans) - Original code
 * 10/2015 (Nat Horner) - General cleanup & commenting
 * 01/2016 (Nat Horner) - Refactored DB; CEMS now in single table, intermediate tables do not persist in DB
 */

show log_min_messages;

DISCARD TEMP;

/* Set replace=1 if you want to throw out existing CEMS data and replace it;
   set replace=0 if you want to add new records to the existing CEMS table. */
SET @replace=1;

/* Define the years to import */
SET @beg_yr=2006;	
SET @end_yr=2018;

/* Define file locations */
SET @dir_raw='C:\\Marginal emissions factor data\\CEMS\\unzipped\\'; -- location of downloaded, unzipped CEMS yearly data directories


PRINT '*******';
PRINT 'IMPORTING RAW DATA FOR YEARS '+CAST(@beg_yr AS STRING)+' - '+CAST(@end_yr AS STRING);
PRINT '*******';

CREATE TEMP TABLE x1 -- temp table to hold raw csv inputs
(
	State char(2), Facility_Name varchar(255), ORISPL_Code numeric,
	UnitID varchar(10), Op_Date date, Op_Hour numeric, Op_Time numeric,
	Gload numeric , SLoad numeric, SO2Mass numeric,SO2Flag varchar(255), SO2_Rate numeric,SO2_RateFlag varchar(255),
	NOxRate numeric, NoxRateFlag varchar(30), NOxMass numeric, NOxMassFlag varchar(255) ,
	CO2Mass numeric, CO2MassFlag varchar(255) , CO2Rate numeric, CO2RateFlag varchar(255) ,
	HeatInput numeric, Fac_ID varchar(30), Unit_ID varchar(20) 	
);

-- List of plant IDs that are present in egrid data
CREATE temporary table egrid_orispl as
select distinct orispl from egrid_plants;

-- Destination table
SET @ToTable='CEMS';

IF @replace =1
BEGIN
	DROP table @ToTable;
	CREATE table @ToTable (yr int, state char(2), orispl numeric, unitid varchar(20), dt date, hr numeric, gload numeric, so2mass numeric, noxmass numeric, co2mass numeric, heatinput numeric, in_egrid int);
END

SET @yr=@beg_yr; -- YEAR iterator
WHILE @yr<=@end_yr -- For each year...
	Begin
	
	SET @J=1; --STATE iterator
	WHILE @J<49 -- For each state...
		Begin
		
		IF @J=1 SET @ST='al'; 
		ELSE IF @J=2 SET @ST='az'; ELSE IF @J=3 SET @ST='ar'; ELSE IF @J=4 SET @ST='ca'; ELSE IF @J=5 SET @ST='co'; ELSE IF @J=6 SET @ST='ct'; ELSE IF @J=7 SET @ST='de';
		ELSE IF @J=8 SET @ST='fl'; ELSE IF @J=9 SET @ST='ga'; ELSE IF @J=10 SET @ST='id'; ELSE IF @J=11 SET @ST='il'; ELSE IF @J=12 SET @ST='in'; ELSE IF @J=13 SET @ST='ia';ELSE IF @J=14 SET @ST='ks';
		ELSE IF @J=15 SET @ST='ky'; ELSE IF @J=16 SET @ST='la'; ELSE IF @J=17 SET @ST='me'; ELSE IF @J=18 SET @ST='md'; ELSE IF @J=19 SET @ST='ma'; ELSE IF @J=20 SET @ST='mi'; ELSE IF @J=21 SET @ST='mn';
		ELSE IF @J=22 SET @ST='ms'; ELSE IF @J=23 SET @ST='mo'; ELSE IF @J=24 SET @ST='mt'; ELSE IF @J=25 SET @ST='ne'; ELSE IF @J=26 SET @ST='nv'; ELSE IF @J=27 SET @ST='nh';
		ELSE IF @J=28 SET @ST='nj'; ELSE IF @J=29 SET @ST='nm'; ELSE IF @J=30 SET @ST='ny'; ELSE IF @J=31 SET @ST='nc'; ELSE IF @J=32 SET @ST='nd';
		ELSE IF @J=33 SET @ST='oh'; ELSE IF @J=34 SET @ST='ok'; ELSE IF @J=35 SET @ST='or'; ELSE IF @J=36 SET @ST='pa'; ELSE IF @J=37 SET @ST='ri';
		ELSE IF @J=38 SET @ST='sc'; ELSE IF @J=39 SET @ST='sd'; ELSE IF @J=40 SET @ST='tn'; ELSE IF @J=41 SET @ST='tx'; ELSE IF @J=42 SET @ST='ut';
		ELSE IF @J=43 SET @ST='vt'; ELSE IF @J=44 SET @ST='va'; ELSE IF @J=45 SET @ST='wa'; ELSE IF @J=46 SET @ST='wv'; ELSE IF @J=47 SET @ST='wi';
		ELSE IF @J=48 SET @ST='wy'; ELSE SET @ST='z';

		truncate table x1;
		
		SET @I=1; -- MONTH iterator
		WHILE @I <13 -- For each month...
		Begin
			-- Create the file name to import
			IF @I<10 SET @T=@dir_raw + CAST(@yr AS STRING) +'/' + CAST(@yr AS STRING) + @ST + '0' + CAST(@I AS STRING) + '.csv';
			ELSE SET @T=@dir_raw + CAST(@yr AS STRING) +'/' + CAST(@yr AS STRING) + @ST + CAST(@I AS STRING) + '.csv';

			-- Import the csv file into the temp table
			COPY x1 FROM '@T' WITH FORCE NULL op_hour, op_time, gload, sload, so2mass, so2flag, so2_rate, so2_rateflag, noxrate, noxrateflag, noxmass, noxmassflag, co2mass, co2massflag, co2rate, co2rateflag, heatinput CSV HEADER;

			SET @I = @I + 1;
		END

		-- Store the relevant information from temp table into CEMS table
		INSERT INTO @ToTable (yr, state, orispl, unitid, dt, hr, gload, so2mass, noxmass, co2mass, heatinput)
		SELECT @yr, state, orispl_code, unitID, op_date, op_hour
			 , cast(gload as numeric)*op_time as gload
			 , so2mass, noxmass, co2mass, heatinput  
		from x1;

		SET @J=@J+1;
	END
SET @yr=@yr+1;
END

UPDATE @ToTable SET in_egrid = 1 WHERE orispl in (SELECT orispl FROM egrid_orispl);

-- Create aggregation at plant level, omitting erroneous entries where plants are on but not emitting
DROP TABLE cems_agg_by_plant;
CREATE TABLE cems_agg_by_plant AS
SELECT yr, orispl, dt, hr, sum(gload) AS gload_MWh, sum(so2mass) AS so2_lbs, sum(noxmass) AS nox_lbs, sum(co2mass) AS co2_tons
FROM cems
WHERE gload > 0 AND heatinput > 0 AND (co2mass * 907.185)/gload < 300
GROUP BY yr, orispl, dt, hr
ORDER BY yr, orispl, dt, hr;

-- Create indices to speed queries
CREATE INDEX cems_orispl_idx ON cems(orispl);
CREATE INDEX cems_idx ON cems (in_egrid, yr, orispl, dt, hr, gload, so2mass, noxmass, co2mass, heatinput); --covering index 
CREATE INDEX cems_st_idx ON cems (in_egrid, yr, state, dt, hr, gload, so2mass, noxmass, co2mass, heatinput); --covering index
CREATE INDEX cems_yr_idx ON cems (yr);
