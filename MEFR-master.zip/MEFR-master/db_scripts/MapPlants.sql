﻿/* *****
 * MARGINAL IMPACT FACTORS REPOSITORY PROJECT
 * 
 * This script creates a mapping from plant to NERC/eGRID/ISO/RTO regions, using the most recent
 * eGRID data for each plant.
 *
 * CHANGE LOG:
 * 11/2015 (Nat Horner) - Code created
 * 01/2016 (Nat Horner) - Minor updates to work with new database
 */

------------------------------------
-- PART 1
------------------------------------

DROP TABLE plant_geography;

SELECT t1.orispl, t1.lat, t1.lon, t1.pstatabb AS state, t1.fips, t1.nerc, t1.subrgn AS egrid, t1.pcaid, t1.pcaname AS pca, 
	t1.isorto, t1.yr, t1.plpfgnct AS gen_type, t1.plfuelct AS fuel, t1.plprmfl AS fuel_subtype, 
	t1.namepcap AS capacity_mw, 1 AS in_egrid
INTO plant_geography
FROM egrid_plants AS t1
LEFT OUTER JOIN egrid_plants AS t2
	ON t1.orispl = t2.orispl AND t1.yr < t2.yr -- Assign to region according to most recent year in the database
WHERE t2.orispl IS NULL;

-- If primary generation type is null, see if there's a value for an earlier year
UPDATE plant_geography
SET gen_type=(SELECT MIN(plpfgnct) FROM egrid_plants
	WHERE egrid_plants.orispl=plant_geography.orispl AND plpfgnct IS NOT NULL)
WHERE gen_type IS NULL;

-- If fuel type is null, see if there's a value for an earlier year
UPDATE plant_geography
SET fuel=(SELECT MIN(plfuelct) FROM egrid_plants
	WHERE egrid_plants.orispl=plant_geography.orispl AND plfuelct IS NOT NULL)
WHERE fuel IS NULL;

-- If fuel subtype is null, see if there's a value for an earlier year
UPDATE plant_geography
SET fuel_subtype=(SELECT MIN(plprmfl) FROM egrid_plants
	WHERE egrid_plants.orispl=plant_geography.orispl AND plprmfl IS NOT NULL)
WHERE fuel_subtype IS NULL;

-- Create table of plants in CEMS but not in eGRID for manual lookup
-- Export this table and fill it in manually
SET @dir_egrid='C:\\Marginal emissions factor data\\EGRID 2012\\';
SET @plants_raw = @dir_egrid + 'CEMS_plants_not_in_egrid_raw.csv';
COPY (
SELECT DISTINCT orispl, state from cems WHERE gload>0 AND orispl NOT IN (SELECT orispl FROM egrid_plants)
) TO '@plants_raw' with CSV HEADER;


------------------------------------
-- PART 2
------------------------------------

-- Include plants from CEMS that are not in eGRID from table produced above -- REQUIRES MANUAL LOOKUP
DROP TABLE IF EXISTS other_plants;
CREATE TEMP TABLE other_plants (
	orispl integer,
	pname varchar(50),
	state varchar(2),
	fuel_subtype varchar(5),
	fuel varchar(5),
	nerc varchar(8),
	egrid varchar(8),
	isorto varchar(8),
	notes varchar(50)
);

SET @dir_egrid='C:\\Marginal emissions factor data\\EGRID 2012\\';
SET @plants = @dir_egrid + 'CEMS_plants_not_in_egrid.csv';
COPY other_plants FROM '@plants' CSV HEADER;

INSERT INTO plant_geography (orispl, state, nerc, egrid, isorto, fuel, in_egrid) 
	SELECT orispl, state, nerc, egrid, isorto, fuel, 0 FROM other_plants;

-- TRE and ERCOT are the same NERC region
UPDATE plant_geography SET nerc = 'TRE' WHERE nerc='ERCOT';

-- Produce plant lat_long table used by time zone python script
SET @dir_egrid='C:\\Marginal emissions factor data\\EGRID 2012\\';
SET @latlon_raw = @dir_egrid + 'plant_lat_lon_raw.csv';
COPY (
SELECT g.orispl, g.state, AVG(e.lat) AS lat, AVG(e.lon) AS lon FROM plant_geography AS g
LEFT JOIN egrid_plants AS e ON g.orispl = e.orispl 
GROUP BY g.orispl, g.state ORDER BY g.orispl
) TO '@latlon_raw' with CSV HEADER;

-- Then run Python script and make manual adjustments to get TZ for each plant

------------------------------------
-- PART 3
------------------------------------

-- Import TZ info and add to plant_geography
DROP TABLE IF EXISTS timezone;
CREATE TEMP TABLE timezone (
	orispl numeric,
	tz varchar(5)
);

SET @dir_egrid='C:\\Marginal emissions factor data\\EGRID 2012\\';
SET @timezone = @dir_egrid + 'plant_tz.csv';
COPY timezone FROM '@timezone' CSV HEADER;

ALTER TABLE plant_geography DROP IF EXISTS tz;
ALTER TABLE plant_geography ADD COLUMN tz varchar(5);

UPDATE plant_geography SET tz = timezone.tz
FROM timezone WHERE plant_geography.orispl = timezone.orispl;

CREATE INDEX map_nerc_idx ON plant_geography (orispl, nerc);
CREATE INDEX map_egrid_idx ON plant_geography (orispl, egrid);
CREATE INDEX map_isorto_idx on plant_geography (orispl, isorto);
CREATE INDEX map_orispl_idx ON plant_geography (orispl, nerc, egrid, state);