﻿/* *****
 * MARGINAL IMPACT FACTORS REPOSITORY PROJECT
 * 
 * This script imports NEI data into the table nei and nei-oris crosswalk into the table
 * neicw.
 *
 * CHANGE LOG:
 * --/---- (Kyle Siler-Evans) - Original code
 * 01/2016 (Nat Horner) - General cleanup & commenting.
 * 02/2016 (Nat Horner) - Added code to calculate and store pm rates by plant and fuel type
 */

/* NEI csv file locations */
SET @dir_nei='C:\\Marginal emissions factor data\\NEI 2011\\';
SET @nei1=@dir_nei + 'process_12345.csv';
SET @nei2=@dir_nei + 'process_678910.csv';

DROP TABLE nei2011;
Create Table nei2011 (
	eis_facility_site_id int,
	program_system_cd varchar(50),
	alt_agency_id varchar(50),
	eis_emissions_unit_id int,
	agency_unit_id varchar(50),
	unit_type_cd int,
	eis_emissions_process_id int,
	agency_process_id varchar(50),
	scc numeric,
	region_cd int, 
	st_usps_cd char(2),
	county_name varchar(50),
	state_and_county_fips_code varchar(50) null,
	tribal_name varchar(255) null,
	facility_site_name varchar(255),
	naics_cd int, 
	facility_source_description varchar(255) null,
	unit_status_code varchar(50) null,
	design_capacity decimal null,
	dc_unit_of_measure varchar(50) null,
	facility_site_status_cd varchar(50) null,
	latitude_msr decimal, 
	longitude_msr decimal,
	location_address_text varchar(255),
	locality varchar(255) null,
	addr_state_cd varchar(255) null,
	address_postal_code varchar(255) null,
	emissions_op_type_code varchar(10),
	emissions_calc_method_desc varchar(255) null,
	emissions_comment varchar(1000) null,
	data_set_short_name varchar(255) null,
	pollutant_cd varchar(255) null,
	description varchar(255) null,
	total_emissions decimal,
	uom varchar(50)
);

COPY nei2011 FROM '@nei1' CSV HEADER;
COPY nei2011 FROM '@nei2' CSV HEADER;

/* Remove non-electricity plants and non PM2.5 pollutants */
DELETE FROM nei2011 WHERE facility_source_description <> 'Electricity Generation via Combustion'
OR (pollutant_cd<>'PM25-PRI' AND pollutant_cd<>'SO2');


/* Import crosswalk table to map to ORIS plant codes */
DROP TABLE neicw2011;
CREATE TABLE neicw2011 (
	EIS_Facility_SiteID Integer,
	Facility_Name varchar(255),
	Company_Name varchar(255),
	NAICS_Code integer,
	Facility_Type_Code integer,
	State_Abbr char(2),
	County_Name varchar(255),
	EIS_Unit_ID numeric,
	Program_System_Code varchar(255),
	Program_System_Description varchar(255),
	Alternate_ID varchar(255),
	Effective_Date date,
	End_Date date,
	Alternate_Identifier_Protected varchar(3)
);

SET @neicw2011 = @dir_nei + 'neicw.csv';
COPY neicw2011 FROM '@neicw2011' CSV HEADER;

-- Format ORIS code
ALTER TABLE neicw2011 ADD orispl int;
UPDATE neicw2011 SET orispl = cast(substring(alternate_id from 1 for position('CAM' in alternate_id)-1) as int);

/* Calculate PM 2.5 emissions rates based on generation. */
CREATE TEMP TABLE gen_2011 AS SELECT orispl, sum(gload) as gen_2011 
	FROM cems
	WHERE yr=2011
	GROUP BY orispl;

DROP TABLE pm25_2011;
CREATE TEMP TABLE pm25_2011 AS SELECT p.orispl AS orispl, cw.eis AS eis, p.gen_type AS gen_type, p.fuel AS fuel, sum(nei2011.total_emissions) AS pm25, nei2011.uom AS unit
	FROM plant_geography AS p 
	LEFT JOIN 
		(SELECT eis_facility_siteid AS eis, orispl FROM neicw2011 GROUP BY orispl, eis) AS cw 
	ON p.orispl=cw.orispl
	LEFT JOIN nei2011 ON cw.eis=nei2011.eis_facility_site_id
	WHERE pollutant_cd='PM25-PRI'
	GROUP BY p.orispl, eis, gen_type, fuel, unit;

-- Calculate only plant rates that have both pm emissions from nei and gload from cems
DROP TABLE plant_pm_rates2011;
CREATE TABLE plant_pm_rates2011 AS SELECT p.orispl, p.gen_type, p.fuel, g.gen_2011 AS MWh_2011, p.pm25 AS pm25tons_2011, p.pm25/g.gen_2011 AS pmrate
	FROM pm25_2011 AS p
	JOIN gen_2011 AS g ON p.orispl=g.orispl
	WHERE p.pm25>0 AND g.gen_2011>0;

-- Fill in biomass as fuel type where missing
UPDATE plant_pm_rates2011
SET fuel=gen_type
WHERE fuel IS NULL;

-- Calculate average pm rate by fuel type
DROP TABLE fuel_pm_rates2011;
CREATE TABLE fuel_pm_rates2011 AS SELECT fuel, AVG(pmrate) AS avg_rate, COUNT(*) AS num_plants
	FROM plant_pm_rates2011
	GROUP BY fuel;

-- Calculate overall average rate
INSERT INTO fuel_pm_rates2011 SELECT 'AVG', AVG(pmrate), COUNT(*) FROM plant_pm_rates2011;
