﻿/* *****
 * MARGINAL IMPACT FACTORS REPOSITORY PROJECT
 * 
 * This script combines CEMS and NEI data with other tables to build the main hourly emissions data.
 *
 * CHANGE LOG:
 * 02/2016 (Nat Horner) - General cleanup & commenting.
 */


/* Note: PM rates for different years are from different NEIs */
DROP TABLE emit_hourly;
CREATE TABLE emit_hourly AS
SELECT cems.yr, cems.dt, hr, cems.orispl, gload_mwh, so2_lbs, nox_lbs, co2_tons, pm.pmrate*cems.gload_mwh AS pm25_tons, pg.fuel, pg.gen_type, pg.fuel_subtype
	FROM cems_agg_by_plant AS cems 
	LEFT JOIN plant_pm_rates2008 AS pm ON cems.orispl=pm.orispl
	LEFT JOIN plant_geography AS pg ON cems.orispl=pg.orispl
	WHERE cems.yr < 2011;

INSERT INTO emit_hourly
SELECT cems.yr, cems.dt, hr, cems.orispl, gload_mwh, so2_lbs, nox_lbs, co2_tons, pm.pmrate*cems.gload_mwh AS pm25_tons, pg.fuel, pg.gen_type, pg.fuel_subtype
	FROM cems_agg_by_plant AS cems 
	LEFT JOIN plant_pm_rates2011 AS pm ON cems.orispl=pm.orispl
	LEFT JOIN plant_geography AS pg ON cems.orispl=pg.orispl
	WHERE cems.yr >= 2011 AND cems.yr < 2014;

INSERT INTO emit_hourly
SELECT cems.yr, cems.dt, hr, cems.orispl, gload_mwh, so2_lbs, nox_lbs, co2_tons, pm.pmrate*cems.gload_mwh AS pm25_tons, pg.fuel, pg.gen_type, pg.fuel_subtype
	FROM cems_agg_by_plant AS cems 
	LEFT JOIN plant_pm_rates2014 AS pm ON cems.orispl=pm.orispl
	LEFT JOIN plant_geography AS pg ON cems.orispl=pg.orispl
	WHERE cems.yr >= 2014 and cems.yr < 2017;

INSERT INTO emit_hourly
SELECT cems.yr, cems.dt, hr, cems.orispl, gload_mwh, so2_lbs, nox_lbs, co2_tons, pm.pmrate*cems.gload_mwh AS pm25_tons, pg.fuel, pg.gen_type, pg.fuel_subtype
	FROM cems_agg_by_plant AS cems 
	LEFT JOIN plant_pm_rates2017 AS pm ON cems.orispl=pm.orispl
	LEFT JOIN plant_geography AS pg ON cems.orispl=pg.orispl
	WHERE cems.yr >= 2017;

/* At this point, only plants in the nei crosswalk have pm emissions set; we will mark these as "calculated" emissions
   and then assign the missing pm emissions to the fuel type average. */

-- Set flag for calculated rate
ALTER TABLE emit_hourly ADD pmrateflag varchar(10);
UPDATE emit_hourly SET pmrateflag='CALC' WHERE pm25_tons > 0;

-- Aggregate fuel types (a few plants have more specific fuel types; set to the general type instead)
UPDATE emit_hourly
SET fuel='COAL' WHERE fuel='BIT';
UPDATE emit_hourly
SET fuel='OIL' WHERE fuel='DFO';
UPDATE emit_hourly
SET fuel='GAS' WHERE fuel='NG';

-- Use gen_type and fuel_subtype to set fuel where fuel is null or "other fossil"
UPDATE emit_hourly
SET fuel='BIOMASS' WHERE fuel IS NULL AND fuel_subtype IN ('BLQ', 'WDS', 'LFG', 'OBS', 'MSB');
UPDATE emit_hourly
SET fuel='GAS' WHERE fuel IS NULL AND fuel_subtype IN ('SGC');
UPDATE emit_hourly
SET fuel='GAS' WHERE fuel='OFSL' AND fuel_subtype IN ('OG');

-- If there are plants for which there is no fuel info, assign average rate
UPDATE emit_hourly
SET fuel='AVG' WHERE fuel IS NULL;

-- For plants with no calculated rate, apply average and set flag for averaged rate
--    Different for different years
UPDATE emit_hourly
	SET pm25_tons = (SELECT avg_rate*gload_mwh 
		FROM fuel_pm_rates2008
		WHERE emit_hourly.fuel = fuel_pm_rates2008.fuel),
		pmrateflag = 'AVG'
	WHERE pm25_tons IS NULL AND yr < 2011;

UPDATE emit_hourly
	SET pm25_tons = (SELECT avg_rate*gload_mwh 
		FROM fuel_pm_rates2011
		WHERE emit_hourly.fuel = fuel_pm_rates2011.fuel),
		pmrateflag = 'AVG'
	WHERE pm25_tons IS NULL AND yr >=2011 AND yr < 2014;

UPDATE emit_hourly
	SET pm25_tons = (SELECT avg_rate*gload_mwh 
		FROM fuel_pm_rates2014
		WHERE emit_hourly.fuel = fuel_pm_rates2014.fuel),
		pmrateflag = 'AVG'
	WHERE pm25_tons IS NULL AND yr >= 2014 AND yr < 2017;

UPDATE emit_hourly
	SET pm25_tons = (SELECT avg_rate*gload_mwh 
		FROM fuel_pm_rates2017
		WHERE emit_hourly.fuel = fuel_pm_rates2017.fuel),
		pmrateflag = 'AVG'
	WHERE pm25_tons IS NULL AND yr >= 2017;

-- Drop unneeded generation type and fuel subtype columns
ALTER TABLE emit_hourly DROP COLUMN gen_type, DROP COLUMN fuel_subtype;

-- Drop plants in Alaska and Hawaii
DELETE FROM emit_hourly AS e
USING plant_geography AS g
WHERE e.orispl = g.orispl AND (g.state = 'AK' or g.state = 'HI');

/* Shift time zones to absolute time */
ALTER TABLE emit_hourly DROP IF EXISTS ts;
ALTER TABLE emit_hourly ADD COLUMN ts timestamp without time zone;

UPDATE emit_hourly SET ts = dt + (hr || 'hours')::INTERVAL;

/* Shift hours in each time zone before aggregating.
	EPT = no shift
	CPT = +1 (Hour 1 CPT --> Hour 2 EPT)
	MPT = +2
	PPT = +3 */

UPDATE emit_hourly AS e SET ts = ts + INTERVAL '1 hour' 
FROM plant_geography AS g
WHERE e.orispl = g.orispl AND g.tz='CPT';

UPDATE emit_hourly AS e SET ts = ts + INTERVAL '2 hours' 
FROM plant_geography AS g
WHERE e.orispl = g.orispl AND g.tz='MPT';

UPDATE emit_hourly AS e SET ts = ts + INTERVAL '3 hours' 
FROM plant_geography AS g
WHERE e.orispl = g.orispl AND g.tz='PPT';

-- Remove unneeded columns
ALTER TABLE emit_hourly DROP yr, DROP dt, DROP hr;

-- Due to TZ shift, first 3 hours and last 3 hours only include partial demand; drop them.
DELETE FROM emit_hourly WHERE ts < 
	(SELECT MIN(ts) FROM emit_hourly) + INTERVAL '3 hours';
DELETE FROM emit_hourly WHERE ts > 
	(SELECT MAX(ts) FROM emit_hourly) - INTERVAL '3 hours';

-- Create a covering index to speed queries
CREATE INDEX idx_emit ON emit_hourly (orispl, ts, gload_mwh, so2_lbs, nox_lbs, co2_tons, pm25_tons);
