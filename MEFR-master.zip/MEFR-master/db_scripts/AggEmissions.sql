﻿/* *****
 * MARGINAL IMPACT FACTORS REPOSITORY PROJECT
 * 
 * This script aggregates the hourly emissions by various regions and writes out the results as .csv
 *
 * CHANGE LOG:
 * 03/2016 (Nat Horner) - Created.
 * 04/2016 (Nat Horner) - Added damage fields.
 * 04/2018 (Priya Donti) - Added isorto aggregation
 */

/* CONVERSION FACTORS */
SET @metton_per_lb=0.000453592; -- Convert pounds to metric tons
SET @metton_per_ton=0.907185; -- Convert short tons to metric tons
SET @CO2_value=40; -- CO2 damages in $/ metric ton

/* Join without aggregate */
DROP TABLE IF EXISTS emit;
CREATE TEMP TABLE emit AS (
SELECT 	ts, e.orispl, nerc, isorto, egrid, state,
	gload_mwh, 
	so2_lbs,
	nox_lbs,
	pm25_tons,
	co2_tons,
	so2_lbs * @metton_per_lb * ap2.so2 AS so2_dam_ap2,
	nox_lbs * @metton_per_lb * ap2.nox AS nox_dam_ap2,
	pm25_tons * @metton_per_ton * ap2.pm25 AS pm25_dam_ap2,
	so2_lbs * @metton_per_lb * eas.so2 AS so2_dam_eas,
	nox_lbs * @metton_per_lb * eas.nox AS nox_dam_eas,
	pm25_tons * @metton_per_ton * eas.pm25 AS pm25_dam_eas,	
	co2_tons * @metton_per_ton * @CO2_value AS co2_dam
FROM emit_hourly as e
LEFT JOIN (SELECT orispl, nerc, isorto, egrid, state FROM plant_geography) as g
	ON e.orispl = g.orispl
LEFT JOIN (SELECT * FROM dam_ap2) AS ap2
	ON e.orispl = ap2.orispl AND extract(year from ts) = ap2.yr
LEFT JOIN (SELECT * FROM dam_easiur) AS eas
	ON e.orispl = eas.orispl
);

/* Aggregate hourly by NERC region */
DROP TABLE IF EXISTS emit_agg_by_nerc;
SELECT 	ts, nerc, 
	sum(gload_mwh) as gload_mwh, 
	sum(so2_lbs) as so2_lbs,
	sum(nox_lbs) as nox_lbs,
	sum(co2_tons) as co2_tons,
	sum(pm25_tons) as pm25_tons,
	sum(so2_dam_ap2) as so2_dam_ap2,
	sum(nox_dam_ap2) as nox_dam_ap2,
	sum(pm25_dam_ap2) as pm25_dam_ap2,
	sum(so2_dam_eas) as so2_dam_eas,
	sum(nox_dam_eas) as nox_dam_eas,
	sum(pm25_dam_eas) as pm25_dam_eas,
	sum(co2_dam) as co2_dam
INTO TEMP emit_agg_by_nerc
FROM emit
GROUP BY ts, nerc
ORDER BY ts, nerc;

SET @outfile='C:\\Marginal emissions factor data\\Regression Input\\emit_agg_by_nerc.csv';
COPY (
SELECT ts, nerc,
	gload_mwh, so2_lbs, nox_lbs, 
	to_char(pm25_tons, 'FM99999999.0000') AS pm25_tons,
	co2_tons,
	to_char(so2_dam_ap2, 'FM99999999.00') AS so2_dam_ap2,
	to_char(nox_dam_ap2, 'FM99999999.00') AS nox_dam_ap2,
	to_char(pm25_dam_ap2, 'FM99999999.00') AS pm25_dam_ap2,
	to_char(so2_dam_eas, 'FM99999999.00') AS so2_dam_eas,
	to_char(nox_dam_eas, 'FM99999999.00') AS nox_dam_eas,
	to_char(pm25_dam_eas, 'FM99999999.00') AS pm25_dam_eas,
	to_char(co2_dam, 'FM99999999.00') AS co2_dam
FROM emit_agg_by_nerc
) TO '@outfile' WITH CSV HEADER;

/* Aggregate hourly by ISO/RTO */
DROP TABLE IF EXISTS emit_agg_by_isorto;
SELECT 	ts, isorto, 
	sum(gload_mwh) as gload_mwh, 
	sum(so2_lbs) as so2_lbs,
	sum(nox_lbs) as nox_lbs,
	sum(co2_tons) as co2_tons,
	sum(pm25_tons) as pm25_tons,
	sum(so2_dam_ap2) as so2_dam_ap2,
	sum(nox_dam_ap2) as nox_dam_ap2,
	sum(pm25_dam_ap2) as pm25_dam_ap2,
	sum(so2_dam_eas) as so2_dam_eas,
	sum(nox_dam_eas) as nox_dam_eas,
	sum(pm25_dam_eas) as pm25_dam_eas,
	sum(co2_dam) as co2_dam
INTO TEMP emit_agg_by_isorto
FROM emit
GROUP BY ts, isorto
ORDER BY ts, isorto;

SET @outfile='C:\\Marginal emissions factor data\\Regression Input\\emit_agg_by_isorto.csv';
COPY (
SELECT ts, isorto,
	gload_mwh, so2_lbs, nox_lbs, 
	to_char(pm25_tons, 'FM99999999.0000') AS pm25_tons,
	co2_tons,
	to_char(so2_dam_ap2, 'FM99999999.00') AS so2_dam_ap2,
	to_char(nox_dam_ap2, 'FM99999999.00') AS nox_dam_ap2,
	to_char(pm25_dam_ap2, 'FM99999999.00') AS pm25_dam_ap2,
	to_char(so2_dam_eas, 'FM99999999.00') AS so2_dam_eas,
	to_char(nox_dam_eas, 'FM99999999.00') AS nox_dam_eas,
	to_char(pm25_dam_eas, 'FM99999999.00') AS pm25_dam_eas,
	to_char(co2_dam, 'FM99999999.00') AS co2_dam
FROM emit_agg_by_isorto
) TO '@outfile' WITH CSV HEADER;

/* Aggregate hourly by eGRID subregion */
DROP TABLE IF EXISTS emit_agg_by_egrid;
SELECT 	ts, egrid, 
	sum(gload_mwh) as gload_mwh, 
	sum(so2_lbs) as so2_lbs,
	sum(nox_lbs) as nox_lbs,
	sum(co2_tons) as co2_tons,
	sum(pm25_tons) as pm25_tons,
	sum(so2_dam_ap2) as so2_dam_ap2,
	sum(nox_dam_ap2) as nox_dam_ap2,
	sum(pm25_dam_ap2) as pm25_dam_ap2,
	sum(so2_dam_eas) as so2_dam_eas,
	sum(nox_dam_eas) as nox_dam_eas,
	sum(pm25_dam_eas) as pm25_dam_eas,
	sum(co2_dam) as co2_dam
INTO TEMP emit_agg_by_egrid
FROM emit
GROUP BY ts, egrid
ORDER BY ts, egrid;

SET @outfile='C:\\Marginal emissions factor data\\Regression Input\\emit_agg_by_egrid.csv';
COPY (
SELECT ts, egrid,
	gload_mwh, so2_lbs, nox_lbs, 
	to_char(pm25_tons, 'FM99999999.0000') AS pm25_tons,
	co2_tons,
	to_char(so2_dam_ap2, 'FM99999999.00') AS so2_dam_ap2,
	to_char(nox_dam_ap2, 'FM99999999.00') AS nox_dam_ap2,
	to_char(pm25_dam_ap2, 'FM99999999.00') AS pm25_dam_ap2,
	to_char(so2_dam_eas, 'FM99999999.00') AS so2_dam_eas,
	to_char(nox_dam_eas, 'FM99999999.00') AS nox_dam_eas,
	to_char(pm25_dam_eas, 'FM99999999.00') AS pm25_dam_eas,
	to_char(co2_dam, 'FM99999999.00') AS co2_dam
FROM emit_agg_by_egrid
) TO '@outfile' WITH CSV HEADER;

/* Aggregate hourly by state */
DROP TABLE IF EXISTS emit_agg_by_state;
SELECT 	ts, state, 
	sum(gload_mwh) as gload_mwh, 
	sum(so2_lbs) as so2_lbs,
	sum(nox_lbs) as nox_lbs,
	sum(co2_tons) as co2_tons,
	sum(pm25_tons) as pm25_tons,
	sum(so2_dam_ap2) as so2_dam_ap2,
	sum(nox_dam_ap2) as nox_dam_ap2,
	sum(pm25_dam_ap2) as pm25_dam_ap2,
	sum(so2_dam_eas) as so2_dam_eas,
	sum(nox_dam_eas) as nox_dam_eas,
	sum(pm25_dam_eas) as pm25_dam_eas,
	sum(co2_dam) as co2_dam
INTO TEMP emit_agg_by_state
FROM emit
GROUP BY ts, state
ORDER BY ts, state;

SET @outfile='C:\\Marginal emissions factor data\\Regression Input\\emit_agg_by_state.csv';
COPY (
SELECT ts, state,
	gload_mwh, so2_lbs, nox_lbs, 
	to_char(pm25_tons, 'FM99999999.0000') AS pm25_tons,
	co2_tons,
	to_char(so2_dam_ap2, 'FM99999999.00') AS so2_dam_ap2,
	to_char(nox_dam_ap2, 'FM99999999.00') AS nox_dam_ap2,
	to_char(pm25_dam_ap2, 'FM99999999.00') AS pm25_dam_ap2,
	to_char(so2_dam_eas, 'FM99999999.00') AS so2_dam_eas,
	to_char(nox_dam_eas, 'FM99999999.00') AS nox_dam_eas,
	to_char(pm25_dam_eas, 'FM99999999.00') AS pm25_dam_eas,
	to_char(co2_dam, 'FM99999999.00') AS co2_dam
FROM emit_agg_by_state
) TO '@outfile' WITH CSV HEADER;
