﻿/* *****
 * MARGINAL IMPACT FACTORS REPOSITORY PROJECT
 * 
 * This script imports AP2 and EASIUR damages.
 *
 * CHANGE LOG:
 * 10/2015 (Nat Horner) - Created script
 */

SET @dir_raw='C:\\Marginal emissions factor data\\Damage Data\\'; -- location of damage data

SET @f_EASIUR=@dir_raw + '\\EASIUR.csv';
SET @f_AP2=@dir_raw + '\\AP2_interp_extrap.csv';

DROP TABLE IF EXISTS dam_EASIUR;
CREATE TABLE dam_EASIUR (ORISPL Numeric, nox Numeric, pm25 Numeric, so2 Numeric);

DROP TABLE IF EXISTS dam_AP2;
CREATE TABLE dam_AP2 (orispl Numeric, yr Numeric, nox Numeric, pm25 Numeric, so2 Numeric);

COPY dam_AP2 FROM '@f_AP2' CSV HEADER;
COPY dam_EASIUR FROM '@f_EASIUR' CSV HEADER;
