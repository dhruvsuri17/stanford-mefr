﻿/* *****
 * MARGINAL IMPACT FACTORS REPOSITORY PROJECT
 * 
 * This script imports NEI data into the table nei and nei-oris crosswalk into the table
 * neicw.
 *
 * CHANGE LOG:
 * --/---- (Kyle Siler-Evans) - Original code
 * 01/2016 (Nat Horner) - General cleanup & commenting.
 * 02/2016 (Nat Horner) - Added code to calculate and store pm rates by plant and fuel type
 */

/* NEI csv file locations */
SET @dir_nei='C:\\Marginal emissions factor data\\NEI 2014\\';
SET @nei1=@dir_nei + 'process_12345.csv';
SET @nei2=@dir_nei + 'process_678910.csv';

DROP TABLE nei2014;
Create Table nei2014 (
    eis_facility_site_id int,
    program_system_cd varchar(50),
    alt_agency_id varchar(50),
    eis_emissions_unit_id int,
    agency_unit_id varchar(50),
    unit_type varchar(255),
    eis_emissions_process_id int,
    agency_process_id varchar(50),
    scc numeric,
    region_cd int, 
    st_usps_cd char(2),
    county_name varchar(50),
    state_and_county_fips_code varchar(50) null,
    tribal_name varchar(255) null,
    facility_site_name varchar(255),
    naics_cd int, 
    naics_description varchar(255) null,
    facility_source_type varchar(255) null,
    design_capacity varchar(255) null,
    dc_unit_of_measure varchar(50) null,
    location_address_text varchar(255),
    locality varchar(255) null,
    addr_state_cd varchar(255) null,
    address_postal_code varchar(255) null,
    source_data_set varchar(255) null,
    pollutant_cd varchar(255) null,
    pollutant_desc varchar(255) null,
    latitude_msr decimal, 
    longitude_msr decimal,
    total_emissions decimal,
    uom varchar(50),
    data_set varchar(255) null  
);

COPY nei2014 FROM '@nei1' CSV HEADER;
/* Deal with null latitude and longitude values */
COPY nei2014 FROM '@nei2' WITH FORCE NULL latitude_msr, longitude_msr CSV HEADER;

/* Remove non-electricity plants and non PM2.5 pollutants */
DELETE FROM nei2014 WHERE facility_source_type <> 'Electricity Generation via Combusti'
OR (pollutant_cd<>'PM25-PRI' AND pollutant_cd<>'SO2');


/* Import crosswalk table to map to ORIS plant codes */
DROP TABLE neicw2014;
CREATE TABLE neicw2014 (
     EIS_Facility_SiteID Integer,
     Facility_Name varchar(255),
     Company_Name varchar(255),
     NAICS_Code integer,
     Facility_Type_Code integer,
     State_Abbr char(2),
     County_Name varchar(255),
     EIS_Unit_ID numeric,
     Program_System_Code varchar(255),
     Program_System_Description varchar(255),
     Alternate_ID varchar(255),
     Effective_Date date,
     End_Date date,
     Alternate_Identifier_Protected varchar(3)
);

SET @neicw2014 = @dir_nei + 'neicw.csv';
COPY neicw2014 FROM '@neicw2014' CSV HEADER;

-- Format ORIS code
ALTER TABLE neicw2014 ADD orispl int;
UPDATE neicw2014 SET orispl = cast(substring(alternate_id from 1 for position('CAM' in alternate_id)-1) as int);

/* Calculate PM 2.5 emissions rates based on generation. */
DROP TABLE gen_2014;
CREATE TEMP TABLE gen_2014 AS SELECT orispl, sum(gload) as gen_2014 
    FROM cems
    WHERE yr=2014
    GROUP BY orispl;

DROP TABLE pm25_2014;
CREATE TEMP TABLE pm25_2014 AS SELECT p.orispl AS orispl, cw.eis AS eis, p.gen_type AS gen_type, p.fuel AS fuel, sum(nei2014.total_emissions) AS pm25, nei2014.uom AS unit
    FROM plant_geography AS p 
    LEFT JOIN 
        (SELECT eis_facility_siteid AS eis, orispl FROM neicw2014 GROUP BY orispl, eis) AS cw 
    ON p.orispl=cw.orispl
    LEFT JOIN nei2014 ON cw.eis=nei2014.eis_facility_site_id
    WHERE pollutant_cd='PM25-PRI'
    GROUP BY p.orispl, eis, gen_type, fuel, unit;

-- Calculate only plant rates that have both pm emissions from nei and gload from cems
DROP TABLE plant_pm_rates2014;
CREATE TABLE plant_pm_rates2014 AS SELECT p.orispl, p.gen_type, p.fuel, g.gen_2014 AS MWh_2014, p.pm25 AS pm25tons_2014, p.pm25/g.gen_2014 AS pmrate
    FROM pm25_2014 AS p
    JOIN gen_2014 AS g ON p.orispl=g.orispl
    WHERE p.pm25>0 AND g.gen_2014>0;

-- Fill in biomass as fuel type where missing
UPDATE plant_pm_rates2014
SET fuel=gen_type
WHERE fuel IS NULL;

-- Calculate average pm rate by fuel type
DROP TABLE fuel_pm_rates2014;
CREATE TABLE fuel_pm_rates2014 AS SELECT fuel, AVG(pmrate) AS avg_rate, COUNT(*) AS num_plants
    FROM plant_pm_rates2014
    GROUP BY fuel;

-- Calculate overall average rate
INSERT INTO fuel_pm_rates2014 SELECT 'AVG', AVG(pmrate), COUNT(*) FROM plant_pm_rates2014;