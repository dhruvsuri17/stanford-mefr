﻿/* *****
 * MARGINAL IMPACT FACTORS REPOSITORY PROJECT
 * 
 * This query is used to output a table containing emissions and damages from
 * CEMS, EASIUR, and AP2 data.
 *
 * INPUTS:
 * - Set beginning and ending years at the beginning of code below
 * - Set output directory
 * - AP2 and EASIUR damage factor data should be in $/metric ton of pollutant and already
 *	imported into the database
 *
 * CHANGE LOG:
 * 10/2015 (Nat Horner) - Created. 
 */

SET @yr_beg=2007;
SET @yr_end=2014;

SET @dir_results='C:\\Marginal emissions factor data\\Query Results\\';

/* * CONVERSION FACTORS * */
SET @metton_per_lb=0.000453592; -- Convert pounds to metric tons
SET @metton_per_ton=0.907185; -- Convert short tons to metric tons
SET @CO2_value=40; -- CO2 damages in $/ metric ton

SET @yr=@yr_beg;
WHILE @yr<=@yr_end
BEGIN
	SET @tabfrom='agg_by_plant' + CAST(@yr AS STRING);
	SET @f_results=@dir_results+'\\'+@tabfrom+'.csv';
	SET @f_missAP2=@dir_results+'\\Missing_ap2_'+CAST(@yr AS STRING)+'.csv';
	SET @f_missEAS=@dir_results+'\\Missing_easiur_'+CAST(@yr AS STRING)+'.csv';
	COPY(
	SELECT emit.*, 
		to_char(emit.so2mass * @metton_per_lb * eas.so2, 'FM99999999.00') AS so2dam_eas,  
		to_char(emit.noxmass * @metton_per_lb * eas.nox, 'FM99999999.00') AS noxdam_eas, 
		to_char(emit.so2mass * @metton_per_lb * ap2.so2, 'FM99999999.00') AS so2dam_ap2,
		to_char(emit.noxmass * @metton_per_lb * ap2.nox, 'FM99999999.00') AS noxdam_ap2,
		to_char(emit.co2mass * @metton_per_ton * @CO2_value, 'FM99999999.00') AS co2dam_40
	FROM	(@tabfrom AS emit LEFT JOIN dam_easiur AS eas ON emit.orisp = eas.orispl)
		LEFT JOIN dam_ap2 AS ap2 on emit.orisp=ap2.orispl
	) TO '@f_results' WITH CSV HEADER;

	-- Get plants missing in damage data
	-- AP2
	COPY(
	SELECT DISTINCT emit.orisp FROM @tabfrom AS emit
		LEFT JOIN dam_ap2 ON emit.orisp=dam_ap2.orispl
	WHERE dam_ap2.orispl IS NULL
	) TO '@f_missAP2' WITH CSV HEADER;
	-- EASIUR
	COPY(
	SELECT DISTINCT emit.orisp FROM @tabfrom AS emit
		LEFT JOIN dam_easiur ON emit.orisp=dam_easiur.orispl
	WHERE dam_easiur.orispl IS NULL
	) TO '@f_missEAS' WITH CSV HEADER;
SET @yr=@yr+1;
END