﻿/* *****
 * MARGINAL IMPACT FACTORS REPOSITORY PROJECT
 * 
 * This script creates a table from NEI data that aggregates annual PM2.5 and SO2 emissions
 * into a table.  Used to regress PM2.5 on SO2 emissions to see if hourly PM2.5 emissions
 * can be esimated this way.
 *
 * CHANGE LOG:
 * 02/2016 (Nat Horner) - Original code.
 */

DROP TABLE IF EXISTS pollute_2011;
CREATE TEMP TABLE pollute_2011 AS 
	SELECT pm.eisid,
		pm.pm25,
		pm.pmUnits,
		pm.p1,
		so.so2,
		so.so2Units,
		so.p2
	FROM (
		SELECT eis_facility_site_id AS eisid,
			SUM(total_emissions) AS pm25,
			uom AS pmUnits,
			pollutant_cd AS p1
		FROM nei 
		WHERE pollutant_cd='PM25-PRI'
		GROUP BY eis_facility_site_id, uom, pollutant_cd
	) AS pm
	JOIN (
		SELECT eis_facility_site_id AS eisid,
			SUM(total_emissions) AS so2,
			uom AS so2Units,
			pollutant_cd AS p2
		FROM nei 
		WHERE pollutant_cd='SO2'
		GROUP BY eis_facility_site_id, uom, pollutant_cd
	) AS so
	ON pm.eisid=so.eisid 
	ORDER BY eisid;

SELECT * from pollute_2011;

/* Join with fuel type */

DROP TABLE IF EXISTS nei_pollute;
CREATE TEMP TABLE nei_pollute AS
SELECT emit.*, cw.orispl, p.fuel, p.gen_type, p.fuel_subtype FROM pollute_2011 AS emit
LEFT JOIN (SELECT eis_facility_siteid AS eis, orispl FROM neicw GROUP BY eis, orispl) AS cw
ON emit.eisid = cw.eis
LEFT JOIN plant_geography AS p
ON cw.orispl=p.orispl;

-- Note: some facility IDs map to different ORIS IDs in the nei crosswalk, so there are duplicates
SELECT * FROM nei_pollute;


