# MEFR
## Marginal Emissions Factors Project

This file last updated June 2017. For best results, view this file in a Markdown reader.

This project is gradually becoming more organized (and the codebase better engineered), but there still may be some aspects of the code that need clarification.  Contact [Nat Horner](nch@cmu.edu) with questions.

There are currently three main components of the project, loosely organized around the following process:

1. Collect, process, and store the raw CEMS and EIA data
2. Run regressions to estimate emissions and damage factors
3. Publish the emissions and damage factors to the research community

The three corresponding code components are stored in  the following GitHub sub-directories:

- `DB Scripts` contains a series of SQL scripts used for importing CEMS and other data into the database, processing it, and exporting regression input data
- `calcMFR` is an R package containing functions used to run the emissions and damage factor regressions.  The file `runregs.r` is an R script that uses these functions to run the regressions.
- `MarginalFactors` is a Shiny app that provides an interface to view and download the emissions and damage factors.  It can be published to [shinyapps.io](https://cedm.shinyapps.io/MarginalFactors/) via RStudio using the CEDM account.

In addition:

- `Other Analysis Code` contains an early version of the regression code and various other code files that have been used in the past for analyzing the data.


