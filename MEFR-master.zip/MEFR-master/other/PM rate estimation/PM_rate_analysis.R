# Code to analyze the plant PM rates from NEI
# @author: Nat Horner
# @date: 2/2016

# --------------------------------------------------------------
# METHOD 1: Calculate PM2.5 rate for plants that we know; use
# average rate for fuel type for other plants.

# PM rates come from the 'plant_pm_rates' table in the MEFR DB,
# which are calculated as: PM2.5 (from NEI) / 
#                          generation (from CEMS)

rplant <- read.csv("plant_pm_rates.csv", header=T)

# Linear regressions find average rate by fuel type
coal <- lm(rplant[rplant$fuel=="COAL",]$pmrate~1)
oil <- lm(rplant[rplant$fuel=="OIL",]$pmrate~1)
gas <- lm(rplant[rplant$fuel=="GAS",]$pmrate~1)
bio <- lm(rplant[rplant$fuel=="BIOMASS",]$pmrate~1)

# Look at residuals (actual rate - average rate) by fuel type
par(mfrow=c(2,3), mar=c(2,3,1.5,1))
plot(coal$residuals, main="Coal")
plot(gas$residuals, main="Gas")
plot(oil$residuals, main="Oil")
plot(bio$residuals, main="Biomass")

# Residuals as percentage
par(mfrow=c(2,3), mar=c(2,3,1.5,1))
plot(coal$residuals/coal$coef, main="Coal")
plot(gas$residuals/gas$coef, main="Gas")
plot(oil$residuals/oil$coef, main="Oil")
plot(bio$residuals/bio$coef, main="Biomass")


# Plot residuals as relative
# plot((coal$residuals-coal$fitted.values)/coal$fitted.values, main="Coal")

# --------------------------------------------------------------
# METHOD 2: Calculate PM2.5 from SO2 using NEI annual data; apply
# this rate to hourly SO2 data from CEMS to get hourly PM2.5.
# 
library(scales)
library(ggplot2)

# Run the NEI_PM_SO2 SQL query and export results for this csv.
nei <- read.csv("nei_pm_so2.csv", header=T)
# Change null fuel values to be "Unknown"
levels(nei$fuel)[1] <- "UNKNOWN"

# if we joined using neicw, there are duplicates
# Note: this is dumb delete; we are not selecting which to drop
nei <- nei[!duplicated(nei$eisid),]

# Drop observations that have emissions in one pollutant but not the other
nei <- nei[!xor(nei$pm25, nei$so2),]

# How many observations have no emissions
nrow(nei[nei$pm25==0 | nei$so2==0,])

hist(log(nei$pm25+0.01), breaks="Scott")
hist(log(nei$so2+0.01), breaks="Scott")

# Simple level-level linear model
m1 <- lm(pm25 ~ so2, data=nei)

# Look for Box-Cox Lambda for power transform of response
library(car)
bc <- boxCox(nei$pm25+0.01 ~ nei$so2)
bc_lam <- bc$x[bc$y == max(bc$y)] 
bc_lam
# Close to zero, so log-transform?


# log-log model
m2 <- lm(log(pm25+0.01) ~ log(so2+0.01), data=nei)

# log-log models, separate by fuel type
m.gas <- lm(log(pm25+0.01) ~ log(so2+0.01), data=nei[nei$fuel=="GAS",])
m.coal <- lm(log(pm25+0.01) ~ log(so2+0.01), data=nei[nei$fuel=="COAL",])

# Plot the log-log regression, coloring by fuel type
colpal <- c("gray60", "orange", "blue", "black", "red")

ggplot(nei, aes(x=log(so2+0.01), y=log(pm25+0.01), color=fuel)) + geom_point(alpha=0.5) +
  geom_abline(intercept=m.gas$coefficients[1], slope=m.gas$coefficients[2], color="darkblue") +
  geom_abline(intercept=m.coal$coefficients[1], slope=m.coal$coefficients[2], color="darkorange") +
#  geom_abline(intercept=m2$coefficients[1], slope=m2$coefficients[2]) +
  scale_color_manual(values=colpal) +
  theme_bw() 

# Calculate the level-level regressions by fuel type
m.gas <- lm(pm25 ~ so2, data=nei[nei$fuel=="GAS",])
m.coal <- lm(pm25 ~ so2, data=nei[nei$fuel=="COAL",])

# Plot the level regression ,coloring by fuel type
ggplot(nei, aes(x=so2, y=pm25, color=fuel)) + geom_point(alpha=0.5) +
  geom_abline(intercept=m.gas$coefficients[1], slope=m.gas$coefficients[2], color="darkblue") +
  geom_abline(intercept=m.coal$coefficients[1], slope=m.coal$coefficients[2], color="darkorange") +
  #  geom_abline(intercept=m2$coefficients[1], slope=m2$coefficients[2]) +
  scale_color_manual(values=colpal) +
  theme_bw()

summary(m.coal)


