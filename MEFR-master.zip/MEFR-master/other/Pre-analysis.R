# Data summary & analysis of generation and demand data
#

datadir <- "C:/Marginal emissions factor data/Regression Input/"

region.type <- "nerc"

# Load the emissions data
f <- paste0(datadir, "emit_agg_by_", region.type, ".csv")
emit.df <- fread(f, header=T, stringsAsFactors=T)

# Load the demand data
f <- paste0(datadir, "demand_agg_by_", region.type, ".csv")
demand.df <- fread(f, header=T, stringsAsFactors=T)

# Merge emissions & demand
df <- merge(demand.df, emit.df, by=c("ts", "nerc"))
df$ts <- as.POSIXct(df$ts, format="%Y-%m-%d %H:%M:%S", tz="Etc/GMT-5")

# Vector of pollutant classes
poll <- c("so2_kg", "nox_kg", "pm25_kg", "co2_kg")

# Change pollutants to kg
df$so2_lbs <- df$so2_lbs * kg.per.lb
df$nox_lbs <- df$nox_lbs * kg.per.lb
df$pm25_tons <- df$pm25_tons * kg.per.ton
df$co2_tons <- df$co2_tons * kg.per.ton
colnames(df)[5:8] <- poll

df <- mutate(df, 
              year= as.POSIXlt(ts)$"year" + 1900,
              month = as.POSIXlt(ts)$"mon" + 1,
              day = as.POSIXlt(ts)$"mday",
              hour = as.POSIXlt(ts)$"hour")

df$fyear <- factor(df$year)

sp <- ggplot(data=filter(df, year >= 2011), aes(x=demand_mwh, y=gload_mwh, color=fyear)) + 
  geom_point(alpha=0.05) +
  expand_limits(y=0) +
  geom_abline(slope=1, intercept=0, color="blue") +
  facet_wrap(facets="nerc", scales="free") + theme_bw()

jpeg("gen_dem_scatter.jpg", height=800, width=800)
sp
dev.off()

# Average emissions
aefs <- df %>% group_by(year, nerc) %>% summarise(so2.d = sum(so2_kg)/sum(demand_mwh),
                                                  so2.g = sum(so2_kg)/sum(gload_mwh),
                                                  nox.d = sum(nox_kg)/sum(demand_mwh),
                                                  nox.g = sum(nox_kg)/sum(gload_mwh),
                                                  pm25.d = sum(pm25_kg)/sum(demand_mwh),
                                                  pm25.g = sum(pm25_kg)/sum(gload_mwh),
                                                  co2.d = sum(co2_kg)/sum(demand_mwh),
                                                  co2.g = sum(co2_kg)/sum(gload_mwh))

write.csv(aefs, "aefs.csv", row.names=F)


# Change to generic region
colnames(df)[2] <- "region"



gen <- gen %>% filter(year > 2010)

# Load the demand data
f <- paste0(datadir, "\\demand_agg_by_", region.type, ".csv")
dem <- fread(f, header=T, stringsAsFactors=T)

dem$ts <- as.POSIXct(dem$ts, format="%Y-%m-%d %H:%M:%S", tz="Etc/GMT-5")
colnames(demand.df)[2] <- "region"

dem <- mutate(dem, 
              year= as.POSIXlt(ts)$"year" + 1900,
              month = as.POSIXlt(ts)$"mon" + 1,
              day = as.POSIXlt(ts)$"mday",
              hour = as.POSIXlt(ts)$"hour")

colnames(dem)[2] <- "region"

dem <- dem %>% filter(year > 2010)

gen.monthly <- gen %>% group_by(region, year, month) %>% summarise(avg_monthly=sum(gload_mwh)) %>%
  mutate(date=as.Date(paste(year, month, "1", sep="/")))
dem.monthly <- dem %>% group_by(region, year, month) %>% summarise(avg_monthly=sum(demand_mwh)) %>%
  mutate(date=as.Date(paste(year, month, "1", sep="/")))

pdf("gen_and_demand_ts.pdf", height=6, width=10)
ggplot() + geom_line(data=gen.monthly, aes(date, avg_monthly, color="Generation")) + 
  geom_line(data=dem.monthly, aes(date, avg_monthly, color="Demand")) + facet_wrap("region", ncol=4) +theme_bw() +
  labs(y="Monthly Load (MWh)", x="Year") + scale_color_manual(name="Load Type", values=c("Generation" = "blue", "Demand" = "red"))
dev.off()

# Check overall generation
gen.monthly.us <- group_by(gen.monthly, year, month) %>% summarise(monthly.gen = sum(avg_monthly))

eia.gen <- read.csv("C:/Users/nhorner/Documents/analysis/monthly_gen_eia.csv")
gen.check <- gen.monthly.us %>% left_join(eia.gen)

colnames(gen.check) <- c("year", "month", "cems", "eia")
gen.check$cems <- gen.check$cems/1000
gen.check$diff <- (gen.check$eia - gen.check$cems) / gen.check$eia


# Check overall demand
dem.monthly.us <- group_by(dem.monthly, year, month) %>% summarise(monthly.dem = sum(avg_monthly))
eia.dem <- read.csv("C:/Users/nhorner/Documents/analysis/monthly_dem_eia.csv")
dem.check <- dem.monthly.us %>% left_join(eia.dem) %>% filter(!is.na(sales))
dem.check$monthly.dem <- dem.check$monthly.dem/1000

dem.check$diff <- (dem.check$sales - dem.check$monthly.dem) / dem.check$sales

summary(dem.check$diff)*100


#Sum up annual demand in each region
head(dem)

dem.annual <- dem %>% group_by(region, year) %>% summarise(annual_mwh=sum(demand_mwh))

dem.annual <- dem.annual %>% filter(year==2014)
dem.annual$annual_mwh <- dem.annual$annual_mwh/1000000
colnames(dem.annual)[3] <- "annual_Twh"


load <- gen %>% join(dem)
load <- mutate(load, diff=(demand_mwh - gload_mwh)/1000)  # in Gwh

pdf("dem-gen_hist.pdf", height=4, width=8)
ggplot(load, aes(diff)) + geom_histogram(bins=50) + facet_wrap("region", ncol=4) + geom_vline(aes(xintercept=0), color="red", linetype="dashed") +
  labs(x="Hourly Demand - Generation (Gwh)") + theme_bw() + scale_x_continuous(breaks=c(0, 45, 90))
dev.off()

