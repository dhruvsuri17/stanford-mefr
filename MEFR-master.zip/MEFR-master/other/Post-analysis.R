# Code to analyze the emissions factors

library(plyr)
library(data.table)
library(reshape2)
library(dplyr)
library(ggplot2)
library(gridExtra)
library(cowplot)


panel.cor <- function(x, y, digits = 2, cex.cor, ...)
{
  usr <- par("usr"); on.exit(par(usr))
  par(usr = c(0, 1, 0, 1))
  # correlation coefficient
  r <- cor(x, y)
  txt <- format(c(r, 0.123456789), digits = digits)[1]
  txt <- paste("r= ", txt, sep = "")
  text(0.5, 0.6, txt, cex=1.5)
}

panel.hist <- function(x, ...)
{
  usr <- par("usr"); on.exit(par(usr))
  par(usr = c(usr[1:2], 0, 1.4) )
  h <- hist(x, plot = FALSE)
  breaks <- h$breaks; nB <- length(breaks)
  y <- h$counts; y <- y/max(y)
  rect(breaks[-nB], 0, breaks[-1], y, col="steelblue2")
}

# Function to pull the in-region mef from the big multivariate demand mf matrix
#
# df - the big matrix to collapse
# n - the number of ID columns at the beginning of the matrix to keep
collapseMultiDemand <- function(df, n) {
  # Get the "primary" MEF (the MEF for the region in region) in the same column
  # There is surely a better way to do this, but I kept running into difficulties, so I went with a 3-step approach that worked
  # 1 - get the column name
  df <- df %>% mutate(this_region = colnames(df)[as.numeric(region)+4])
  # 2 - get the column index from the name
  df <- mutate(df, this_col = match(this_region, colnames(df)))
  # 3 - grab the value from the column index
  df$this_mf <- as.numeric(df[cbind(1:nrow(df), df$this_col)])
  
  return(select(df, 1:n, this_mf))
}


datadir <- "C:\\Marginal emissions factor data\\Regression Input"
resultdir <- "C:\\Marginal emissions factor data\\Regression Results\\2016-results current"

# Load results

# monthly
#M1
f <- paste0(resultdir, "\\Generation_MAR_EMIT_nerc_by-Month.csv")
r.gen.monthly <- fread(f, header=T, stringsAsFactors=T) %>% mutate(year = factor(year))

#M2
f <- paste0(resultdir, "\\Demand_MAR_EMIT_nerc_by-Month.csv")
r.dem.monthly <- fread(f, header=T, stringsAsFactors=T) %>% mutate(year = factor(year))

#M3
f <- paste0(resultdir, "\\Demand-Multi_MAR_EMIT_nerc_by-Month.csv")
r.demdem.monthly <- fread(f, header=T, stringsAsFactors=T) %>% select(1:4, contains("mef")) %>% mutate(year = factor(year))
r.demdem.monthly <- collapseMultiDemand(r.demdem.monthly, 4)

#M4
f <- paste0(resultdir, "\\Diff-Multi_MAR_EMIT_nerc_by-Month.csv")
r.demdiff.monthly <- fread(f, header=T, stringsAsFactors=T) %>% select(1:5) %>% mutate(year = factor(year))

#M5
f <- paste0(resultdir, "\\Diff-Multi_AVG_EMIT_nerc_by-Month.csv")
r.diffavg.monthly <- fread(f, header=T, stringsAsFactors=T) %>% select(1:5) %>% mutate(year = factor(year))

m1.sum <- r.gen.monthly %>% filter(year == 2011 | year == 2012 | year == 2013 | year == 2014) %>% group_by(region, pollutant) %>%
  summarise(m1.mean = mean(mf), m1.median=median(mf), m1.min=min(mf), m1.max=max(mf))
m2.sum <- r.dem.monthly %>% filter(year == 2011 | year == 2012 | year == 2013 | year == 2014) %>% group_by(region, pollutant) %>%
  summarise(m2.mean = mean(mf), m2.median=median(mf), m2.min=min(mf), m2.max=max(mf))
m3.sum <- r.demdem.monthly %>% filter(year == 2011 | year == 2012 | year == 2013 | year == 2014) %>% group_by(region, pollutant) %>%
  summarise(m3.mean = mean(this_mf), m3.median=median(this_mf), m3.min=min(this_mf), m3.max=max(this_mf))
m4.sum <- r.demdiff.monthly %>% filter(year == 2011 | year == 2012 | year == 2013 | year == 2014) %>% group_by(region, pollutant) %>%
  summarise(m4.mean = mean(mef_d_load), m4.median=median(mef_d_load), m4.min=min(mef_d_load), m4.max=max(mef_d_load))
m5.sum <- r.diffavg.monthly %>% filter(year == 2011 | year == 2012 | year == 2013 | year == 2014) %>% group_by(region, pollutant) %>%
  summarise(m5.mean = mean(mef_mwh), m5.median=median(mef_mwh), m5.min=min(mef_mwh), m5.max=max(mef_mwh))

sumtbl <- m1.sum %>% left_join(m2.sum) %>% left_join(m3.sum) %>% left_join(m4.sum) %>% left_join(m5.sum)
write.csv(sumtbl, "model_summaries.csv", row.names=F)

# PM2.5
g.pm <- ggplot() + 
  geom_line(data = filter(r.gen.monthly, (year == 2011 | year == 2012 | year == 2013 | year == 2014) & pollutant=="pm25_kg"), 
            aes(month, mf, color=year), size=2) +
  geom_line(data = filter(r.dem.monthly, (year == 2011 | year == 2012 | year == 2013 | year == 2014) & pollutant=="pm25_kg"),
            aes(month, mf, color=year)) +
#   geom_line(data = filter(r.demdem.monthly, (year == 2011 | year == 2012 | year ==2013 | year ==2014) & pollutant=="pm25_kg"),
#             aes(month, this_mf, color=year), linetype="dotted") +
  geom_line(data = filter(r.demdiff.monthly, (year == 2011 | year == 2012 | year ==2013 | year ==2014) & pollutant=="pm25_kg"),
            aes(month, mef_d_load, color=year), linetype="dashed") +
  geom_line(data = filter(r.diffavg.monthly, (year == 2011 | year == 2012 | year == 2013 | year == 2014) & pollutant=="pm25_kg"),
            aes(month, mef_mwh, color=year)) +
  facet_wrap(facets=c("region"), ncol=4) + labs(y="PM2.5 MEF (kg/Mwh)") + scale_x_continuous(breaks=seq(0, 12, 2)) + theme_bw()

# NOX
g.nox <- ggplot() + 
  geom_line(data = filter(r.gen.monthly, (year == 2011 | year ==2012 | year == 2013 | year == 2014) & pollutant=="nox_kg"), 
            aes(month, mf, color=year), size=2) +
  geom_line(data = filter(r.dem.monthly, (year == 2011 | year ==2012 | year == 2013 | year == 2014) & pollutant=="nox_kg"),
            aes(month, mf, color=year)) +
  geom_line(data = filter(r.demdiff.monthly, (year == 2011 | year == 2012 | year ==2013 | year ==2014) & pollutant=="nox_kg"),
            aes(month, mef_d_load, color=year), linetype="dashed") +
  geom_line(data = filter(r.demdem.monthly, (year == 2011 | year == 2012 | year ==2013 | year ==2014) & pollutant=="nox_kg"),
            aes(month, this_mf, color=year), linetype="dotted") +
  facet_wrap(facets=c("region"), ncol=4) + labs(y="NOx MEF (kg/Mwh)") + scale_x_continuous(breaks=seq(0, 12, 2)) + theme_bw()

# SO2
g.so2 <- ggplot() + 
  geom_line(data = filter(r.gen.monthly, (year == 2011 | year ==2012 | year == 2013 | year == 2014) & pollutant=="so2_kg"), 
            aes(month, mf, color=year), size=2) +
  geom_line(data = filter(r.dem.monthly, (year == 2011 | year ==2012 | year == 2013 | year == 2014) & pollutant=="so2_kg"),
            aes(month, mf, color=year)) +
  geom_line(data = filter(r.demdiff.monthly, (year == 2011 | year == 2012 | year ==2013 | year ==2014) & pollutant=="so2_kg"),
            aes(month, mef_d_load, color=year), linetype="dashed") +
  geom_line(data = filter(r.demdem.monthly, (year == 2011 | year == 2012 | year ==2013 | year ==2014) & pollutant=="so2_kg"),
            aes(month, this_mf, color=year), linetype="dotted") +
  facet_wrap(facets=c("region"), ncol=4) + labs(y="SO2 MEF (kg/Mwh)") + scale_x_continuous(breaks=seq(0, 12, 2)) + theme_bw()
 

# CO2
g.co2 <- ggplot() + 
  geom_line(data = filter(r.gen.monthly, (year == 2011 | year ==2012 | year == 2013 | year == 2014) & pollutant=="co2_kg"), 
            aes(month, mf, color=year)) +
  geom_line(data = filter(r.dem.monthly, (year == 2011 | year ==2012 | year == 2013 | year == 2014) & pollutant=="co2_kg"),
            aes(month, mf, color=year)) +
  geom_line(data = filter(r.demdiff.monthly, (year == 2011 | year == 2012 | year ==2013 | year ==2014) & pollutant=="co2_kg"),
            aes(month, mef_d_load, color=year), linetype="dashed") +
  geom_line(data = filter(r.demdem.monthly, (year == 2011 | year == 2012 | year ==2013 | year ==2014) & pollutant=="co2_kg"),
            aes(month, this_mf, color=year), linetype="dotted") +
  facet_wrap(facets=c("region"), ncol=4) + labs(y="CO2 MEF (kg/Mwh)") + scale_x_continuous(breaks=seq(0, 12, 2)) + theme_bw()

pdf("MEF_monthly.pdf", width=12, height=16)
grid.arrange(g.pm, g.nox, g.so2, g.co2, ncol=1)
dev.off()


# hours

f <- paste0(resultdir, "\\Generation_MAR_EMIT_nerc_by-TOD.csv")
r.gen <- fread(f, header=T, stringsAsFactors=T)
r.gen$year <- factor(r.gen$year)

f <- paste0(resultdir, "\\Demand_MAR_EMIT_nerc_by-TOD.csv")
r.dem <- fread(f, header=T, stringsAsFactors=T)
r.dem$year <- factor(r.dem$year)

f <- paste0(resultdir, "\\Diff-Multi_MAR_EMIT_nerc_by-TOD.csv")
r.demdiff <- fread(f, header=T, stringsAsFactors=T) %>% select(1:5) %>% mutate(year = factor(year))

f <- paste0(resultdir, "\\Demand-Multi_MAR_EMIT_nerc_by-TOD.csv")
r.demdem <- fread(f, header=T, stringsAsFactors=T) %>% select(1:4, contains("mef")) %>% mutate(year = factor(year))
r.demdem <- collapseMultiDemand(r.demdem, 4)

# PM2.5
g.pm <- ggplot() + 
  geom_line(data = filter(r.gen, (year == 2011 | year ==2012 | year == 2013 | year == 2014) & pollutant=="pm25_kg"), 
            aes(hour, mf, color=year), size=1) +
  geom_line(data = filter(r.dem, (year == 2011 | year ==2012 | year == 2013 | year == 2014) & pollutant=="pm25_kg"),
            aes(hour, mf, color=year)) +
  geom_line(data = filter(r.demdiff, (year == 2011 | year == 2012 | year ==2013 | year ==2014) & pollutant=="pm25_kg"),
            aes(hour, mef_d_load, color=year), linetype="dashed") +
  geom_line(data = filter(r.demdem, (year == 2011 | year == 2012 | year ==2013 | year ==2014) & pollutant=="pm25_kg"),
            aes(hour, this_mf, color=year), linetype="dotted") +
  facet_wrap(facets=c("region"), ncol=4) + labs(y="PM2.5 MEF (kg/Mwh)") + scale_x_continuous(breaks=seq(0, 24, 2)) + theme_bw()

# NOX
g.nox <- ggplot() + 
  geom_line(data = filter(r.gen, (year == 2011 | year ==2012 | year == 2013 | year == 2014) & pollutant=="nox_kg"), 
            aes(hour, mf, color=year), size=1) +
  geom_line(data = filter(r.dem, (year == 2011 | year ==2012 | year == 2013 | year == 2014) & pollutant=="nox_kg"),
            aes(hour, mf, color=year)) +
  geom_line(data = filter(r.demdiff, (year == 2011 | year == 2012 | year ==2013 | year ==2014) & pollutant=="nox_kg"),
            aes(hour, mef_d_load, color=year), linetype="dashed") +
  geom_line(data = filter(r.demdem, (year == 2011 | year == 2012 | year ==2013 | year ==2014) & pollutant=="nox_kg"),
            aes(hour, this_mf, color=year), linetype="dotted") +
  facet_wrap(facets=c("region"), ncol=4) + labs(y="NOx MEF (kg/Mwh)") + scale_x_continuous(breaks=seq(0, 24, 2)) + theme_bw()

# SO2
g.so2 <- ggplot() + 
  geom_line(data = filter(r.gen, (year == 2011 | year ==2012 | year == 2013 | year == 2014) & pollutant=="so2_kg"), 
            aes(hour, mf, color=year), size=1) +
  geom_line(data = filter(r.dem, (year == 2011 | year ==2012 | year == 2013 | year == 2014) & pollutant=="so2_kg"),
            aes(hour, mf, color=year)) +
  geom_line(data = filter(r.demdiff, (year == 2011 | year == 2012 | year ==2013 | year ==2014) & pollutant=="so2_kg"),
            aes(hour, mef_d_load, color=year), linetype="dashed") +
  geom_line(data = filter(r.demdem, (year == 2011 | year == 2012 | year ==2013 | year ==2014) & pollutant=="so2_kg"),
            aes(hour, this_mf, color=year), linetype="dotted") +
  facet_wrap(facets=c("region"), ncol=4) + labs(y="SO2 MEF (kg/Mwh)") + scale_x_continuous(breaks=seq(0, 24, 2)) + theme_bw()

# CO2
g.co2 <- ggplot() + 
  geom_line(data = filter(r.gen, (year == 2011 | year ==2012 | year == 2013 | year == 2014) & pollutant=="co2_kg"), 
            aes(hour, mf, color=year), size=1) +
  geom_line(data = filter(r.dem, (year == 2011 | year ==2012 | year == 2013 | year == 2014) & pollutant=="co2_kg"),
            aes(hour, mf, color=year)) +
  geom_line(data = filter(r.demdiff, (year == 2011 | year == 2012 | year ==2013 | year ==2014) & pollutant=="co2_kg"),
            aes(hour, mef_d_load, color=year), linetype="dashed") +
  geom_line(data = filter(r.demdem, (year == 2011 | year == 2012 | year ==2013 | year ==2014) & pollutant=="co2_kg"),
            aes(hour, this_mf, color=year), linetype="dotted") +
  facet_wrap(facets=c("region"), ncol=4) + labs(y="CO2 MEF (kg/Mwh)") + scale_x_continuous(breaks=seq(0, 24, 2)) + theme_bw()

pdf("MEF_hourly.pdf", width=12, height=16)
grid.arrange(g.pm, g.nox, g.so2, g.co2, ncol=1)
dev.off()





# Compare generation and demand ---------------

f <- paste0(datadir, "\\demand_agg_by_nerc.csv")
demand.df <- fread(f, header=T, stringsAsFactors=T)

demand.df <- demand.df %>% dcast(ts ~ nerc, value.var = "demand_mwh")
demand.df$ts <- as.POSIXct(demand.df$ts, format="%Y-%m-%d %H:%M:%S")

demand.10 <- demand.df %>% filter(ts >= "2010-01-01" & ts <= "2011-01-01")
demand.14 <- demand.df %>% filter(ts >= "2014-01-01")

jpeg("scattermatrix.jpg", width=600, height=600, units="px", quality=100)
pairs(demand.14[ , -1], lower.panel=panel.smooth, upper.panel = panel.cor, diag.panel=panel.hist, pch=20, col=rgb(0, 0, 0, 0.2))
dev.off()

monthly.old <- read.csv("C:/Marginal emissions factor data/Regression Results/2015-temp/monthly.2010.csv")
monthly.new <- read.csv("C:/Marginal emissions factor data/Regression Results/test/Generation_MAR_EMIT_nerc_by-month.csv")
levels(monthly.new$pollutant) <- c("CO2", "NOx", "PM", "SO2")
monthly.new <- monthly.new %>% filter(year == 2010, pollutant != "PM") %>% select(2:5)
colnames(monthly.old) <- c("month", "mf.old", "pollutant", "region")

compare <- monthly.old %>% join(monthly.new)

compare <- compare %>% mutate("pct" = (mf - mf.old)/mf.old)

p.compare <- ggplot(compare, aes(pollutant, pct)) + geom_boxplot(aes(fill= region))

jpeg("box_month_diff_2010.jpg", width=600, height=600, units="px", quality=100)
p.compare
dev.off()

