import os
import pandas as pd
import numpy as np

# Conversion factors
KG_IN_LB = 0.453592
KG_IN_TON = 907.185

def prep_input(region_type, in_dir, start_year=2006, end_year=2018):
    '''
    Get clean aggregated hourly generation/emissions+damages and the associated 
        generation/emissions+damages differences between hours.

    Inputs:
        region_type: Regional breakdown type (nerc, egrid, isorto, or state)
        in_dir: Directory with CSV files of hourly generation and emissions/damages by region
        start_year: First year for which to keep data
        end_year: Last year for which to keep data

    Outputs:
        emissions: Data frame of hourly emissions and damages by region
        diffs: Data frame of differenced hourly emissions and damages by region
    '''

    # Read in CEMS data, aggregated by region. Drop rows without region label.
    print('...getting emissions/damages data')
    emissions = pd.read_csv(
        os.path.join(in_dir, 'emit_agg_by_{}.csv'.format(region_type)))
    emissions = emissions[pd.notnull(emissions[region_type])]

    # Convert timestamp to datetime
    emissions['ts'] = pd.to_datetime(emissions['ts'])

    # Organize by timestamp and region
    emissions = emissions.set_index(['ts', region_type]).sort_index()
    emissions.index.names = ['DATE_EPT', region_type]

    # Convert units to kg
    emissions = convert_to_kg(emissions, 'lbs', KG_IN_LB)
    emissions = convert_to_kg(emissions, 'tons', KG_IN_TON)

    # Get differenced data, and format columns
    print('...differencing data')
    diffs = get_diffs(emissions, region_type, start_year, end_year)

    return emissions, diffs


def convert_to_kg(df, unit_label, conversion_factor):
    ''' Helper function to convert units to kilograms'''

    # Get columns with given unit, and convert to kg using conversion factor
    old_unit_cols = [x for x in df.columns if unit_label in x]
    df[old_unit_cols] = df[old_unit_cols] * conversion_factor
    df.columns = [x.replace(unit_label, 'kg') for x in df.columns]
    return df


def get_diffs(df, region_type, start_year, end_year):
    ''' 
    Calculate differenced generation/emissions/damages
    Note: df input must be indexed by date and aggregation region
    '''

    # Reindex to ensure all hours and regions are represented
    all_hours = pd.date_range(
        start='{}-01-01'.format(start_year), end='{}-01-01'.format(end_year+1), freq='H')
    all_hours_multidx = pd.MultiIndex.from_product(
        [all_hours, df.index.get_level_values(region_type).unique()], 
        names=['DATE_EPT', region_type])
    df = df.reindex(all_hours_multidx)

    # Sort index by region and then date
    df = df.reset_index().set_index([region_type, 'DATE_EPT']).sort_index()

    # Take diffs and correct "spillover" between boundaries of regions
    diffs = df.diff().reset_index()
    mask = diffs[region_type] != diffs[region_type].shift(1)
    diffs[mask] = np.nan

    # Rearrange back to being sorted by date, then region
    diffs = diffs.set_index(['DATE_EPT', region_type]).sort_index()

    # Drop any null diffs
    diffs = diffs.dropna(how='all')

    return diffs
