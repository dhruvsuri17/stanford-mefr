import os
import pandas as pd
import numpy as np
from scipy.stats import linregress as lm
import statsmodels.api as sm
from prep_input import prep_input

import ipdb
import sys
from IPython.core import ultratb
sys.excepthook = ultratb.FormattedTB(mode='Verbose',
     color_scheme='Linux', call_pdb=1)

# Directories for regression input and output
DATA_DIR = "RegressionInput"
OUT_DIR = "RegressionResults"

# Years for which to calculate factors
START_YEAR = 2006
END_YEAR = 2019

# Region types for which to calculate factors
REGION_TYPES = ['nerc', 'egrid', 'isorto', 'state']

# Global variables for hour groupings and their corresponding columns
#  Valid grouping cols are: year, season, month, hour, and dec
grouping_names = ['SeasonalTOD', 'MonthTOD', 'TOD', 'Year', 'Month', 'Load']
grouping_cols = [['year', 'season', 'hour'], ['year', 'month', 'hour'], 
    ['year', 'hour'], ['year'], ['year', 'month'], ['year', 'dec']]

# Global variables for regression labels and x-column name
LABELS = ['so2_kg', 'nox_kg', 'pm25_kg', 'co2_kg',
    'so2_dam_ap2', 'nox_dam_ap2', 'pm25_dam_ap2', 
    'so2_dam_eas', 'nox_dam_eas', 'pm25_dam_eas',
    'co2_dam']
XCOL = 'gload_mwh'

# Global variables for emissions vs. AP2 vs. EASIUR columns
EMIT_COLS = ['co2_kg', 'so2_kg', 'nox_kg', 'pm25_kg']
DAM_COLS_AP2 = ['co2_dam', 'so2_dam_ap2', 'nox_dam_ap2', 'pm25_dam_ap2']
DAM_COLS_EAS = ['co2_dam', 'so2_dam_eas', 'nox_dam_eas', 'pm25_dam_eas']

def main():

    # Helper function to prepare input and calculate factors per region
    #    (Defining this function helps with memory management)
    def calc_factors_for_region(region):
        print(region)
        emissions, diffs = prep_input(region, DATA_DIR, end_year=END_YEAR)
        calc_factors(emissions, diffs, region, OUT_DIR, end_year=END_YEAR)

    # Run helper function for each region  
    for region in REGION_TYPES:
        calc_factors_for_region(region)


def calc_factors(emissions, diffs, region_type, out_dir, start_year=2006, end_year=2018):
    '''
    Calculate and save marginal and average factors.

    Inputs:
        emissions: Data frame of hourly emissions and damages by region
        diffs: Data frame of differenced hourly emissions and damages by region
        region_type: Regional breakdown type (nerc, egrid, isorto, or state)
        out_dir: Directory to put results
        start_year: First year for which to calculate factors
        end_year: Last year for which to calculate factors

    Outputs:
        None. (All calculated factors are saved to out_dir as CSV files.)
    '''

    print('...prepping data frames')
    emissions_df, diffs_df = prep_dfs(emissions, diffs, region_type, end_year)

    # Helper function to calculate and save AEFs and MEFs for each hour grouping
    def calc_factors_for_grouping(grouping_name, grouping):
        # AEFs
        print('...computing AEFs for {}'.format(grouping_name))
        aefs = calc_aefs(emissions_df, grouping + ['region'])
        save_factors(aefs, region_type, grouping_name, out_dir, False)

        # MEFs
        print('...computing MEFs for {}'.format(grouping_name))
        mefs = calc_mefs(diffs_df, grouping + ['region'])
        save_factors(mefs, region_type, grouping_name, out_dir, True)

    # Run helper function for each grouping
    for grouping_name, grouping in zip(grouping_names, grouping_cols):
        calc_factors_for_grouping(grouping_name, grouping)
        

def prep_dfs(emissions_df, diffs_df, region_type, end_year):
    ''' Prepare data frames for factor calculations'''
    
    # Filter by year, label temporal groupings, and standardize naming
    def prep_indiv_df(df):
        df = df.reset_index().set_index('DATE_EPT')
        df = df[df.index.year <= end_year]
        df = label_temporal_attrs(df)
        df.rename(columns={region_type:'region'}, inplace=True)
        return df
    emissions_df = prep_indiv_df(emissions_df)
    diffs_df = prep_indiv_df(diffs_df)

    # Calculate load deciles within each year and region
    emissions_df, diffs_df = label_load_deciles(emissions_df, diffs_df)

    return emissions_df, diffs_df


def label_temporal_attrs(df):
    ''' Label df rows with year, month, hour, season.'''

    df = df.copy()

    # Get year, month, hour
    df['year'] = df.index.year
    df['month'] = df.index.month
    df['hour'] = df.index.hour

    # Get season
    #  Summer = May-Sept
    #  Winter = Dec-Mar
    #  Transition = Apr, Oct
    month_to_season = ['Winter'] * 3 + ['Trans'] + ['Summer'] * 5 + ['Trans'] + ['Winter'] * 2
    df['season'] = df.index.map(lambda x: month_to_season[x.month - 1])

    return df


def label_load_deciles(raw_df, differenced_df):
    ''' Label df rows with annual load deciles.'''

    # Get deciles by region and year.
    # Note: In some cases for the state regressions (e.g. Vermont 2006), there
    #   are not enough unique values of load for 10 deciles with unique 
    #   ranges/labels. For these groups, we reduce the number of quantiles and
    #   "merge" deciles with non-unique labels (via duplicates='drop' flag)
    deciles = raw_df.groupby(['region', 'year'])['gload_mwh'].transform(
        lambda g: pd.qcut(g, min(10, len(g.dropna().unique())), duplicates='drop'))
    deciles = deciles.apply(lambda x: x.right)  # use decile upper limit for label
    deciles = deciles.apply(lambda x: np.rint(x).astype(int)) # round label to nearest int

    # Label deciles in original (non-differenced) data frame
    raw_df['dec'] = deciles

    # Label deciles in differenced data frame
    differenced_df.set_index([differenced_df.index, 'region'], inplace=True)
    raw_df.set_index([raw_df.index, 'region'], inplace=True)
    differenced_df['dec'] = raw_df['dec'].reindex(differenced_df.index)
    # Restore indices
    raw_df = raw_df.reset_index().set_index('DATE_EPT')
    differenced_df = differenced_df.reset_index().set_index('DATE_EPT')

    return raw_df, differenced_df


def calc_mefs(df, grouping):
    ''' Calculate marginal emissions factors'''

    # Helper function for MEF calculation.
    def calc_mefs_helper(data):
        x = data[XCOL].values
        y = data[LABELS]

        # Run regression for each column and store results
        results = y.apply(lambda v: lm(x,v))

        # Calculate if high leverage
        X_ = sm.add_constant(x)
        try:
            lev = np.diag(X_.dot(np.linalg.inv(X_.T.dot(X_))).dot(X_.T))
            high_lev = int((lev >= 0.3).any())
        except np.linalg.linalg.LinAlgError: # e.g. non-invertible matrix
            high_lev = None

        return results.apply(lambda v: {'reg_result': v, 'high_leverage': high_lev})

    # Get and format MEF calculation (regression) results
    results_df = factor_calculation_helper(df, grouping, calc_mefs_helper)
    results_df = format_regression_results(results_df)

    return results_df


def calc_aefs(df, grouping):
    ''' Calculate average emissions factors'''

    # Helper function for AEF calculation
    def calc_aefs_helper(data):
        sums = data[[XCOL]+LABELS].dropna().sum()
        results = sums[LABELS] / sums[XCOL]
        return results

    # Get and format AEF calculation results
    results_df = factor_calculation_helper(df, grouping, calc_aefs_helper)
    results_df.columns = ['factor']

    return results_df


def factor_calculation_helper(df, grouping, calc_fn):
    ''' Calculate factors given hour grouping and factor calculation function'''

    # Drop null values and group hours by grouping
    # df = df.dropna()
    groups = df.groupby(grouping)

    # Calculate factor within each group
    results_dict = {}
    for name, data in groups:
        results_dict[name] = calc_fn(data)

    # Format results into one data frame
    results_df = pd.DataFrame.from_dict(results_dict, orient='index')
    results_df.index.names = grouping

    # Convert to long format
    results_df = pd.DataFrame(results_df.stack())
    results_df.index.names = results_df.index.names[:-1] + ['pollutant']
    results_df.columns = ['result']

    return results_df


def format_regression_results(results_df):
    ''' Format results of regression used to calculate marginal factors'''

    # Extract slopes, standard error, r-value, and intercept.
    #    Include warning if any point has undue leverage.
    stats_fns = [lambda x: x['reg_result'].slope, 
                 lambda x: x['reg_result'].stderr, 
                 lambda x: x['reg_result'].rvalue**2, 
                 lambda x: x['reg_result'].intercept,
                 lambda x: x['high_leverage']]
    stats_labels = ['factor', 'se', 'r2', 'int', 'warn']


    for fn, label in zip(stats_fns, stats_labels):
        results_df[label] = results_df['result'].apply(fn)
    results_df.drop('result', axis=1, inplace=True)

    # To deal with cases in state + month TOD factors with few datapoints
    #    or only one value of \delta G per grouping.
    #    (Database cannot deal with inf values)
    results_df.replace([np.inf, -np.inf], np.nan, inplace=True) 

    return results_df


def save_factors(df, region_type, grouping_name, out_dir, is_marginal):
    ''' Save calculated factors to file'''

    # Create output directory if it does not exist
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)

    # Format file name
    save_name_base = '{}_Generation_{}_{{}}_{}_by-{}.csv'.format(
        '2' if is_marginal else '1',
        'MAR' if is_marginal else 'AVG',
        region_type.upper(),
        grouping_name)
    save_path_base = os.path.join(out_dir, save_name_base)

    # Save factors separately for emissions, AP2 damages, and EASIUR damages
    def save_factors_helper(df, cols, file_add):
        sub_df = pd.DataFrame(df[df['pollutant'].isin(cols)])
        sub_df['pollutant'] = sub_df['pollutant'].apply(lambda x: x.split('_')[0])
        sub_df.to_csv(save_path_base.format(file_add), index=False)

    df = df.reset_index()
    save_factors_helper(df, EMIT_COLS, 'EMIT')
    save_factors_helper(df, DAM_COLS_AP2, 'DAM-AP2')
    save_factors_helper(df, DAM_COLS_EAS, 'DAM-EASIUR')

if __name__ == '__main__':
    main()

