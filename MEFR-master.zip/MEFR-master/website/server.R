library(shiny)
library(dplyr)
library(dbplyr)
# library(RMySQL)
library(ggplot2)
library(pool)


#mefr_db <- src_sqlite("MEFR.sqlite3")

### Region list

nerc <- c("FRCC", "MRO", "NPCC", "RFC", "SERC", "SPP", "TRE", "WECC")
egrid <- c("AZNM", "CAMX", "ERCT", "FRCC", "MROE", "MROW", "NEWE", "NWPP", "NYCW", "NYLI", "NYUP", 
           "RFCE", "RFCM", "RFCW", "RMPA", "SPNO", "SPSO", "SRMV", "SRMW", "SRSO", "SRTV", "SRVC")
isorto <- c("CAISO", "ERCOT", "ISONE", "MISO", "NYISO", "PJM", "SPP")
state <- c("AL", "AR", "AZ", "CA", "CO", "CT", "DE", "FL", "GA", "IA", "ID", "IL", "IN", "KS", "KY", 
           "LA", "MA", "MD", "ME", "MI", "MN", "MO", "MS", "MT", "NC", "ND", "NE", "NH", "NJ", "NM", 
           "NV", "NY", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VA", "VT", "WA", 
           "WI", "WV", "WY")

frowlength <- 3 # number of columns in plot grid

shinyServer(function(input, output, session) {
  
  # Use pool to manage connections to the database
  mefr_db <- dbPool(
    RMySQL::MySQL(), 
    dbname = "resife",
    host = "se3mydb.stanford.edu",
    port = 3306,
    username = "repo_browser",
    password = "maremit"
  )
  
  session$onSessionEnded(function() {
    dbDisconnect(mefr_db$con)
  })
  
  values <- reactiveValues()
  
  ### UI panels (some defined server-side)
  
  output$emitDamPanel <- renderUI({
    if(input$factor_type == 'AVG' | input$method == 'REG') {
      list(
        selectInput(inputId = "metric", label = "METRIC:",
                  choices = c("Emissions" = "EMIT",
                              "Damages AP2" = "DAMAP2",
                              "Damages EASIUR" = "DAMEASIUR")),
        bsTooltip("metric", paste("Emissions in kg/MWh. Damages calculated for criteria pollutants by AP2 or EASIUR models",
                                "in $/MWh (2010$); CO2 damages based on $40/ton (2010$).", sep=" "), "right")
        )
    } else {
      list(
        selectInput(inputId = "metric", label = "METRIC:",
                  choices = c("Emissions" = "EMIT")),
        bsTooltip("metric", paste("Emissions in kg/MWh.", sep=" "), "right")
      )
    }
  })
  
  output$predictorPanel <- renderUI({
    if(input$factor_type == 'AVG' | input$method == 'REG') {
      list(
        selectInput(inputId = "predictor", label = "PREDICTOR:",
                    choices = c("Year" = "byYear",
                                "Month" = "byMonth",
                                "Hour of day" = "byTOD",
                                "Seasonal hour of day" = "bySeasonalTOD",
                                "Monthly hour of day" = "byMonthTOD",
                                "Load decile" = "byLoad")),
        bsTooltip("predictor", "Factors are estimated based on year, month, hour of day, hour of day by season, and load decile. Hour of day estimates are reported in UTC-5 (NOT local time).", "above")
      )
    } else {
      list(
        selectInput(inputId = "predictor", label = "PREDICTOR:",
                    choices = c("Year" = "byYear",
                                "Month" = "byMonth",
                                "Hour of day" = "byTOD",
                                "Seasonal Hour of day" = "bySeasonalTOD")),
        bsTooltip("predictor", "Factors are estimated based on year, month, hour of day, and hour of day by season. Hour of day estimates are reported in UTC-5 (NOT local time).", "above")
      )
    }
  })
  
  output$regAggPanel <- renderUI({
    if(input$factor_type == 'AVG' | input$method == 'REG') {
      list(
        selectInput(inputId = "region_level", label = "REGIONAL AGGREGATION:",
                    choices = c("NERC region" = "nerc",
                                "eGRID subregion" = "egrid",
                                "ISO/RTO region" = "isorto",
                                "State" = "state")),
        bsTooltip("region_level", "Factors calculated for individual NERC regions (8), eGRID subregions (22), ISO/RTO regions (7), or contiguous states (48).", "above")
      )
    } else {
      list(
        selectInput(inputId = "region_level", label = "REGIONAL AGGREGATION:",
                    choices = c("NERC region" = "nerc")),
        bsTooltip("region_level", "Factors calculated for individual NERC regions (8).", "above")
      )
    }
  })
  
  output$regionSelectDyn <- renderUI({
    if(input$regionSelectAll == "all") {
      switch(input$region_level,
             "nerc" = selectInput(inputId = "region", label = "SELECT REGIONS:",
                                  choices = nerc, multiple=T, size = 8, selected = nerc, selectize=F),
             "egrid" = selectInput(inputId = "region", label = "SELECT REGIONS:",
                                   choices = egrid, multiple=T, size = 8, selected = egrid, selectize=F),
             "isorto" = selectInput(inputId = "region", label = "SELECT REGIONS:",
                                   choices = isorto, multiple=T, size = 8, selected = isorto, selectize=F),
             "state" = selectInput(inputId = "region", label = "SELECT REGIONS:",
                                   choices = state, multiple=T, size = 8, selected = state, selectize=F)
      )
    } else {
      switch(input$region_level,
             "nerc" = selectInput(inputId = "region", label = "SELECT REGIONS:",
                                  choices = nerc, multiple=T, size = 8, selected = nerc[1], selectize=F),
             "egrid" = selectInput(inputId = "region", label = "SELECT REGIONS:",
                                   choices = egrid, multiple=T, size = 8, selected = egrid[1], selectize=F),
             "isorto" = selectInput(inputId = "region", label = "SELECT REGIONS:",
                                    choices = isorto, multiple=T, size = 8, selected = isorto[1], selectize=F),
             "state" = selectInput(inputId = "region", label = "SELECT REGIONS:",
                                   choices = state, multiple=T, size = 8, selected = state[1], selectize=F)
      )
    }
  })  
  
  output$yearSelectPanel <- renderUI({
    if(input$factor_type == 'AVG' | input$method == 'REG') {
        list(
            radioButtons(inputId = "yearSelectAll", label = "TIME RANGE:",
                            choices =c("Select individual years" = "custom",
                                       "All available years (2006-2018)" = "all")),
            bsTooltip("yearSelectAll", "Factors are calculated separately for each year and are available for 2006-2018.", "right"),
            conditionalPanel(
              condition = "input.yearSelectAll == 'custom'",
              switch(input$yearSelectAll,
                     "all" = selectInput(inputId = "year", label = "YEARS:",
                                         choices = c(2006:2018), multiple = T, size = 5, selected = c(2006:2018), selectize = F),
                     "custom" = selectInput(inputId = "year", label = "YEARS:",
                                            choices = c(2006:2018), multiple = T, size = 5, selected = c(2011:2018), selectize = F)
            ))
        )
    } else {
        list(
          radioButtons(inputId = "yearSelectAllSim", label = "TIME RANGE:",
                       choices =c("Select individual years" = "custom",
                                  "All available years (2012-2017)" = "all")),
          bsTooltip("yearSelectAllSim", "Factors are calculated separately for each year and are available for 2006-2017.", "right"),
          conditionalPanel(
            condition = "input.yearSelectAllSim == 'custom'",
            switch(input$yearSelectAllSim,
                   "all" = selectInput(inputId = "year", label = "YEARS:",
                                       choices = c(2012:2017), multiple = T, size = 5, selected = c(2012:2017), selectize = F),
                   "custom" = selectInput(inputId = "year", label = "YEARS:",
                                          choices = c(2012:2017), multiple = T, size = 5, selected = c(2014:2017), selectize = F)
          ))
        )
    }
  })
  
  
  output$yearSelectDyn <- renderUI({
    if(input$yearSelectAll == "all") {
      selectInput(inputId = "year", label = "YEARS:",
                  choices = c(2006:2018), multiple = T, size = 5, selected = c(2006:2018), selectize = F)
    } else if (input$yearSelectAll == "custom") {
      selectInput(inputId = "year", label = "YEARS:",
                  choices = c(2006:2018), multiple = T, size = 5, selected = c(2011:2018), selectize = F)
    }
  })
  
  output$yearSelectDynSim <- renderUI({
    if(input$yearSelectAllSim == "all") {
      selectInput(inputId = "yearSim", label = "YEARS:",
                  choices = c(2012:2017), multiple = T, size = 5, selected = c(2012:2017), selectize = F)
    } else if (input$yearSelectAllSim == "custom") {
      selectInput(inputId = "yearSim", label = "YEARS:",
                  choices = c(2012:2017), multiple = T, size = 5, selected = c(2014:2017), selectize = F)
    }
  })

  
  output$pollutantPanel <- renderUI({
    if(input$factor_type == 'AVG' | input$method == 'REG') {
      list(
        checkboxGroupInput(inputId = "pollutants", label = "POLLUTANTS:",
                           choices = c("SO2" = "so2", "NOx" = "nox", "PM2.5" = "pm25", "CO2" = "co2"),
                           selected = c("so2", "nox", "pm25", "co2")),
        bsTooltip("pollutants", "Factors are calculated separately for 3 criteria pollutants and CO2.", "right")
      )
    } else {
      list(
        checkboxGroupInput(inputId = "pollutants", label = "POLLUTANTS:",
                           choices = c("SO2" = "so2", "NOx" = "nox", "CO2" = "co2"),
                           selected = c("so2", "nox", "co2")),
        bsTooltip("pollutants", "Factors are calculated separately for 2 criteria pollutants and CO2.", "right")
      )
    }
  })

  
  ###### TODO: outfile format
  outfile <- reactive({
    if(input$preview == 0)
      return()
    isolate({
      return(
        paste(
          paste("Generation",
                paste(input$factor_type, ifelse(input$factor_type == "MAR", input$method, ""), sep=""),
                input$metric,
                input$region_level,
                input$predictor, sep="-"),
          "csv", sep=".")
        )
    })
  })
  
  
  data <- reactive({
    if (input$preview == 0)
      return()
    isolate({
      load_type <- "Generation"
      factor_type <- input$factor_type
      method <- input$method
      metric <- input$metric
      region <- input$region_level
      predictor <- input$predictor
      if(factor_type == 'AVG' | method == 'REG') {
        table.name <- tolower(paste(load_type, factor_type, metric, region, predictor, sep="_"))
        years <- c("", input$year)
      } else {
        table.name <- tolower(paste(load_type, factor_type, method, metric, region, predictor, sep="_"))
        years <- c("", input$yearSim)
      }
      
      # Need the empty head for SQL queries
      # years <- c("", input$year)
      regions <- c("", input$region)
      pols <- c("", input$pollutants)
      
      table <- tbl(mefr_db, table.name)
      # Line below is the format given in online examples
      # table <- mefr_db %>% tbl(table.name)
      
      result <- table %>% filter(year %in% years,
                                 region %in% regions,
                                 pollutant %in% pols)
      rlength <- length(regions) - 1
      ylength <- length(years) - 1
      if(predictor == "byYear")
        values$pheight <- max(ceiling(rlength), frowlength) / frowlength * 200
      else if (predictor == "bySeasonalTOD")
        values$pheight <- ceiling((rlength * ylength * 3) / frowlength) * 200
      else 
        values$pheight <- ceiling((rlength * ylength) / frowlength) * 200
      return(result)
    })
  })
  
  outplot <- reactive({
    if (input$preview == 0)
      return()
    isolate({
      data <- collect(data())
      facets <- formula(~ region + year)
      fscale <- "fixed"
      ytitle <- "$/MWh"
      xtitle <- "hour"
      maintitle <- paste(input$factor_type, input$method, input$metric, input$region, input$predictor, sep=" ")
      switch(input$predictor,
             "byYear" = {data$x <- factor(data$year)
                         facets <- formula(~ region) 
                         xtitle <- "Year"}, 
             "byMonth" = {data$x <- factor(data$month)
                          xtitle <- "Month"},
             "byTOD" = data$x <- factor(data$hour),
             "bySeasonalTOD" = {data$x <- factor(data$hour)
                                facets <- formula(~region + season + year)},
             "byLoad" = {data$x <- factor(data$dec)
                         xtitle <- "Load (MWh/h)"
                         fscale <- "free_x"}
      )
      if(input$metric == "EMIT") {
        ytitle <- "kg/MWh"
      }
      
      # Use dodge (not stacked) bars for emissions, stacked for damages
      if(input$metric == "EMIT") {
        graph_type <- "dodge"
      } else {
        graph_type <- "stack"
      }
      
      ggplot(data, aes(x=x, y=factor)) + geom_bar(stat="identity", aes(colour=pollutant, fill = pollutant), position=graph_type) + 
        facet_wrap(facets, scales=fscale, ncol=frowlength) + ylab(ytitle) + xlab(xtitle) + ggtitle(maintitle)
    })
  })
  
  output$pheight <- renderText({
    values$pheight
  })
  
  output$dfilename <- renderText({
    outfile()
  })
  
  output$datatable <- renderTable({
    head(data(), 25)
  })
  
  output$downloadData <- downloadHandler(
    filename = function() {outfile()},
    content = function(file) {
      write.csv(data(), file, na="")
    })
  
  output$pcontents <- renderPlot({
    outplot()
  })
  
  output$mainplot <- renderUI({
    plotOutput("pcontents", height = values$pheight, width = "100%")
  })
})
