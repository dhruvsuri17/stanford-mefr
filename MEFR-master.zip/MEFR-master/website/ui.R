library(shiny)
library(shinyBS)

shinyUI(fluidPage(
  # Define UI for application that draws a histogram
  shinyUI(fluidPage(
    
    # Application title
    titlePanel("Electricity Marginal Factors Estimates"),
    
    # Sidebar with a slider input for the number of bins
    sidebarLayout(
      sidebarPanel(
        h3("Data Selection"),
        p(tags$b(tags$i("Note: Data are preliminary and subject to change."))),
        
        actionButton(inputId = "preview",label = "Refresh"),
        bsTooltip("preview", "Refresh the data and plot."),
        
        downloadButton("downloadData", label = "Download Data"),
        bsTooltip("downloadData", "Download the data based on the filters set below."),
        
        br(),
        br(),
        
        
        ### Marginal vs. average
        selectInput(inputId = "factor_type", label = "FACTOR TYPE:",
                    choices = c("Marginal" = "MAR",
                                "Average" = "AVG")),
        bsTooltip("factor_type", paste("Marginal factors are based on hourly delta(emissions) / delta(load).",
                                       "Average factors are based on hourly emissions / load.", sep=" "), "right"),
        
        
        ### Calculation method for marginal factors
        conditionalPanel(
          condition = "input.factor_type == 'MAR'",
          selectInput(inputId = "method", label = "CALCULATION METHOD:",
                      choices = c("Regression" = "REG",
                                  "Simulated" = "SIM")),
          bsTooltip("method", paste("Regression-based factors are calculated using regression on historical data.",
                                    "Simulated factors are based on a dispatch model.", sep=" "), "right")
        ),
        
        
        ### Emissions or damages. (Only emissions are avail for simulated factors.)
        uiOutput("emitDamPanel"),
        
        
        ### Predictor. (Only temporal versions are avail for simulated factors.)
        uiOutput("predictorPanel"),
        
        
        ### Regional aggregations. (Only NERC avail for simulated factors.)
        uiOutput("regAggPanel"),
        
        
        ### Select all regions or subset.
        radioButtons(inputId = "regionSelectAll", label = "REGIONS:",
                     choices = c("Select specific regions" = "custom",
                                 "Use all regions" = "all")),
        bsTooltip("regionSelectAll", paste("Use all regions at the selected aggregation level, or select a subset of regions.",
                                           "Use command, control, or shift to select multiple regions in the box that will appear below."), "right" ),
        
        conditionalPanel(
          condition = "input.regionSelectAll == 'custom'",
          uiOutput("regionSelectDyn")
        ),
        
        
        ### Select all years or subset. (TODO: Only 2012-2017 avail for simulated factors.)
        conditionalPanel(
          condition = "input.factor_type == 'AVG' || input.method == 'REG'",
          radioButtons(inputId = "yearSelectAll", label = "TIME RANGE:",
                       choices =c("Select individual years" = "custom",
                                  "All available years (2006-2018)" = "all")),
          bsTooltip("yearSelectAll", "Factors are calculated separately for each year and are available for 2006-2018.", "right"),
          conditionalPanel(
            condition = "input.yearSelectAll == 'custom'",
            uiOutput("yearSelectDyn")
          )
        ),
        conditionalPanel(
          condition = "input.method == 'SIM'",
          radioButtons(inputId = "yearSelectAllSim", label = "TIME RANGE:",
                       choices =c("Select individual years" = "custom",
                                  "All available years (2012-2017)" = "all")),
          bsTooltip("yearSelectAllSim", "Factors are calculated separately for each year and are available for 2012-2017.", "right"),
          conditionalPanel(
            condition = "input.yearSelectAllSim == 'custom'",
            uiOutput("yearSelectDynSim")
          )
        ),
        
        
        ### Select pollutants. (PM25 not avail for simulated factors.)
        uiOutput("pollutantPanel")
        
      ),
      
      mainPanel(
        tabsetPanel(
          tabPanel("Intro",
                   h2("About Marginal Factors"),
                   img(src = "CEDM.png", height = 100, width = 100, align="left", style="padding:10px;"),
                   # tags$b("Caution: Data are preliminary and subject to change."),
                   p("This application is maintained by the Climate and Energy Decision Making Center in the
              Department of Engineering and Public Policy at Carnegie Mellon University.  If you use this data set,
                     please cite it:"),
                   p("Azevedo IL, Donti PL, Horner NC, Schivley G, Siler-Evans K, Vaishnav PT (2020). Electricity Marginal Factor Estimates.",  em("Center For Climate and Energy Decision Making.")," Pittsburgh:
Carnegie Mellon University. http://cedmcenter.org" ),
                   p(tags$b("Instructions:"), "Select the relevant data filters on the left, click REFRESH, and then view the plot
                     and/or download the data."),
                   
                   p(tags$b("Documentation:"), "Documentation about how to download and use these factors,",
                     "as well as the methods used to calculate them, can be found",
                     tags$a(href="https://drive.google.com/open?id=1ZhJU4k-Y65oYnFs2CtpPrHt9wafOc0RJ", "at this link.",
                            target="_blank")),
                   
                   p(tags$b("Important notes:")),
                   tags$ul(
                     tags$li("Units:"),
                     tags$ul(
                       tags$li("Emissions factor values are in kg/MWh."),
                       tags$li("Damage factor values are in $/MWh (reported in 2010 dollars).")
                     ),
                     tags$li("Time zones and seasons:"),
                     tags$ul(
                       tags$li("Average and regession-based marginal estimates are reported in Eastern Prevailing Time (EPT)."),
                       tags$li("Simulation (dispatch-based) marginal estimates are reported in local time."),
                       tags$li("The breakdown for seasonal factors is: Winter (Nov-Mar), Summer (May-Sep), and Transition (Apr & Oct).")
                     ),
                     tags$li("Values for monetized damages:"),
                     tags$ul(
                       tags$li("We use a social cost of carbon of $40/metric ton CO2 (in 2010 dollars) for climate change damages."),
                       tags$li("We use a value of statistical life of $8.8 million (in 2010 dollars) for health damages.")
                     ),
                     tags$li("Caveats:"),
                     tags$ul(
                       tags$li(paste(
                         "Factors do not incorporate information about nuclear or renewables.", 
                         "In particular, the (fossil fuel-based) average factors we report are likely higher than true average factor values in practice.")
                       ),
                       tags$li(paste(
                         "Factors broken down by monthly hour of day (predictor) or state (regional aggregation) may be less robust than",
                         "other factors due to their high granularity; please use these factors with caution.")
                       )
                     )
                   ),
                   p(tags$b("Older versions:"), "Previous versions of factors posted on this site can be found",
                     tags$a(href="https://stanford.box.com/s/nql1ypm8n9a2oi7dz7wmlu4y8x3s8ogw", "at this link,",
                            target="_blank"),
                     "with dates corresponding to the change log below."),
                   p(tags$b("Change log:")),
                   tags$ul(
                     tags$li("Jan 30, 2021: Removed most recent factor updates (Dec 30-31, 2020) due to data quality issues."),
                     tags$s(tags$li("Dec 31, 2020: Minor update:"),
                            tags$ul(
                              tags$li("Plant location mapping updated to use data from eGRIDs 2004-2018 (previous: eGRIDs 2004-2012 only)."),
                              tags$li("PM2.5 estimates updated to use NEIs 2008-2017 (previous: NEIs 2008-2014 only).")
                            )),
                     tags$s(tags$li("Dec 30, 2020: Factors for 2019 posted.")),
                     tags$li("Mar 30, 2020: Fixed issue where some emissions and damage factors from 2011-13 were null."),
                     tags$li("Jan 20, 2020: Documentation on downloading/using factors and underlying methods posted."),
                     tags$li("Nov 23, 2019: Major update:"),
                     tags$ul(
                       tags$li("AP2 damage factors updated to use AP2 2005, 2008, and 2011 data (previous: AP2 2011 only)."),
                       tags$li("PM2.5 estimates updated to use NEI 2008, 2011, and 2014 (previous: NEI 2011 only)."),
                       tags$li("Average factor definition changed to use quotient of sums (previous: mean of quotients)."),
                       tags$li("Factors posted for ISO/RTO and state regional aggregations."),
                       tags$li("Factors posted for monthly hour of day predictor.")
                     ),
                     tags$li("Sep 24, 2019: Dispatch-based marginal emissions factors now available."),
                     tags$li("Aug 19, 2019: Factors for 2018 posted."),
                     tags$li("May 17, 2018: Factors for 2017 posted.")
                   )
          ),
          tabPanel("Data Preview", br(), "Output file name: ", textOutput("dfilename"), br(), tableOutput("datatable")),
          tabPanel("Plot", uiOutput("mainplot"))
        )
      )
    )
  ))
))
