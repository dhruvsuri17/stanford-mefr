from sqlalchemy import create_engine
import pandas as pd
import os

def main():

    ## Upload all factors stored in output directories
    OUT_DIRS = [os.path.join(os.pardir, 'calc_factors', 'RegressionResults'),
                os.path.join(os.pardir, 'data', 'simulated_factors')]

    # Connect to DB
    #  DB used at CMU is: "mysql+pymysql://admin:natman@128.2.65.140/resife"
    engine = create_engine("")

    # Helper function to upload each file to its own table
    #    (Defining this function helps with memory management)
    def upload_df_for_file(dirname, f):
        table_name = f[2:-4].replace('-', '').lower()
        print(table_name)
        df = pd.read_csv(os.path.join(dirname, f))
        df.to_sql(table_name, con=engine, index=False, if_exists='replace',
            chunksize=500)

    # Run helper function for each csv file in the output directory
    for out_dir in OUT_DIRS:
        table_files = [x for x in os.listdir(out_dir) if ".csv" in x]
        for f in table_files:
            upload_df_for_file(out_dir, f)



if __name__ == '__main__':
    main()
