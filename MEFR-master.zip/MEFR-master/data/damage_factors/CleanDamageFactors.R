## Code for analyzing AP2, and EASIUR marginal emissions data
## Authors: Brian Sergi and Parth Vaishnav 
## Date created: 8/20/2015

## Document contents:
## 1. Import and format AP2 data
## 2. Import and format EASIUR data
## 3. Merge eGrid and AP2/EASIUR data sets to get marginal damage estimates at each power plant
## 4. Harmonize assumptions across different approaches
## 5. Format for plotting

# load libraries
library(openxlsx)
library(plyr)
library(reshape)
library(foreign)


## 1. Import and format AP2 data

## AP2

# read in AP2 data
AP2 <- read.dta("PPI_Prices_1999_2002_2005_2008_All.dta", convert.dates = TRUE, convert.factors = TRUE,
                          missing.type = FALSE, convert.underscore = FALSE, warn.missing.labels = TRUE)

# read in FIPS code list
fips<- read.dta("AP2_Fips_List.dta", convert.dates = TRUE, convert.factors = TRUE,
                       missing.type = FALSE, convert.underscore = FALSE, warn.missing.labels = TRUE)

# assign fips codes to corresponding stack heights (info from email with Nick Mueller)
# Note: in AP2, area includes ground level sources, low is <250 meters, medium 250-500 meters, and high >500 meters 
fips$stack <- c(rep("area", 3109), rep("low", 3109), rep("medium", 3109), rep("high",656))

# merge AP2 data with fips
AP2 <- cbind(fips, AP2)

# delete extreme column
AP2 <- AP2[,-3]

# melt data frame
AP2 <- melt(AP2, id.vars = c("fips", "stack"))

AP2$pollutant <- gsub("\\_[0-9A-Za-z]+", "", AP2$variable)
AP2$year <- gsub("[0-9A-Za-z]+_", "", AP2$variable)

AP2 <- subset(AP2, select = c(fips, stack, pollutant, year, value))
names(AP2)[5] <- "AP2.value"

AP2 <- reshape(AP2, 
               timevar = c("year"),
               idvar = c("fips", "stack","pollutant"),
               direction = "wide")

rownames(AP2) <- NULL
write.csv(AP2, file = "AP2 original values.csv")

# averages 2005
AP2.2005 <- subset(AP2, select=c(fips, stack, pollutant, AP2.value.2005))

AP2.2005.avg <- ddply(AP2.2005, ~ pollutant, summarize, national.avg = mean(AP2.value.2005))


## 2. Import and format EASIUR data
# Note: EASIUR data imported here based on marginal damage values at different power plant locations using eGrid
# see assumptions for this in the documentation

# All counties

EASIUR.all <- read.csv("EASIUR-2010USD-2010INCOME-20150213-County.csv", header=TRUE)
EASIUR.all  <- subset(EASIUR.all, select = c(Fips, SO2, PEC, NOX))
EASIUR.all <- melt(EASIUR.all, id.vars = c("Fips"))
EASIUR.avg  <- ddply(EASIUR.all, ~variable, summarize, national.avg = mean(value))


# just relevant plants

EASIUR <- read.xlsx("Plant_marginal_damages_EASIUR.xlsx", sheet=1, startRow=2)

# separate EASIUR county and lat-lon data
EASIUR.county <- EASIUR[,c(1,4,10:13)]
EASIUR.latlon <- EASIUR[,c(1,4,14:17)]

names(EASIUR.county)[3] <- "PM25"
names(EASIUR.latlon)[3] <- "PM25"

EASIUR.county <- melt(EASIUR.county, id.vars = c("FIPS", "ORISPL"))
EASIUR.latlon <- melt(EASIUR.latlon, id.vars = c("FIPS", "ORISPL"))

## 3. Merge data sets to get marginal damage estimates at each power plant
# merge will subset APEEP and AP2 data to marginal emissions at power plant locations

EASIUR <- merge(EASIUR.county, EASIUR.latlon, by = c("FIPS", "ORISPL", "variable"))
names(EASIUR)[4:5] <- c("EASIUR.county", "EASIUR.latlon")

# read stack heights
heights <- read.csv("ORISPL-stack height.csv")
EASIUR <- merge(EASIUR, heights, by = "ORISPL")



# merge EASIUR, AP2, and APEEP data
combined <- merge(EASIUR, AP2, by.x = c("FIPS", "variable", "Category"), by.y = c("fips", "pollutant", "stack"))
combined <- merge(combined, APEEP, by.x = c("FIPS", "Category", "variable"), by.y = c("fips", "stack", "variable"))
names(combined)[c(2,3)] <- c( "stack.height", "pollutant")
#combined <- subset(combined, select = -c(stack.height, Stack.Height..meters.))



# 4. Harmonize assumptions across models

### STANDARDIZE VSL AND OTHER ASSUMPTIONS ###

# APEEP assumptions: VSL $2 million, USD 2000$, short tons
# AP2 assumptions: VSL $6 million, USD 2000$, short tons
# EASIUR assumptions: VSL $8.8 million, USD 2010$, metric tons

# AP2
combined[,c("AP2.value.2008", "AP2.value.2005", "AP2.value.2002", "AP2.value.1999")] <- 
      combined[,c("AP2.value.2008", "AP2.value.2005", "AP2.value.2002", "AP2.value.1999")] / 0.907185  # convert to metric tons

#combined[,c(6:9)] <- combined[,c(6:9)] * 1.24      # convert from $2000 to $2010
combined[,c("AP2.value.2008", "AP2.value.2005", "AP2.value.2002", "AP2.value.1999")] <- 
  combined[,c("AP2.value.2008", "AP2.value.2005", "AP2.value.2002", "AP2.value.1999")] * 8.8 / 6   # use same VSL as EASIUR


# APEEP
combined[,"APEEP.value"] <- combined[,"APEEP.value"] / 0.907185  # convert to metric tons
#combined[,10] <- combined[,10] * 1.24      # convert from $2000 to $2010

combined[,"APEEP.value"] <- combined[,"APEEP.value"] * 8.8 / 2   # use same VSL as EASIUR

# output file
write.csv(combined, "marginal_damages_all.csv")


# separate EASIUR latlon and AP2 for 2005

easiur.output <- combined[,c("FIPS", "ORISPL", "stack.height", "EASIUR.latlon", "pollutant")]
ap2.2005.output <- combined[,c("FIPS", "ORISPL", "stack.height", "AP2.value.2005", "pollutant")]

easiur.output <- reshape(easiur.output, 
                         timevar = "pollutant",
                         idvar = c("FIPS", "ORISPL", "stack.height"), 
                         direction = "wide")

ap2.2005.output  <- reshape(ap2.2005.output , 
                            timevar = "pollutant",
                            idvar = c("FIPS", "ORISPL", "stack.height"), 
                            direction = "wide")

names(easiur.output)[4:6] <- c("NOx", "PM25", "SO2")
names(ap2.2005.output)[4:6] <- c("NOx", "PM25", "SO2")

write.csv(easiur.output, file = "EASIUR latlon values.csv")
write.csv(ap2.2005.output, file = "AP2 2005 values.csv")



############



## 5. code for plotting

# subset data frames by pollution type
pm25 <- combined[combined$pollutant == "PM25",]
so2 <- combined[combined$pollutant == "SO2",]
nox <- combined[combined$pollutant == "NOX",]

library(ggplot2)
source("http://klein.co.uk/R/myfunctions.R")
#install.packages("car")
library("car")
#install.packages("tseries")
library("tseries")
#install.packages("lmtest")
library("lmtest")


# PLOTTING THREE-WAY COMPARISONS

# Option 1: GGally
#install.packages("GGally")
library(GGally)

png(filename  = "pm25_AP2.png",
    width  = 3000,
    height = 3000,
    res    = 300)
ggpairs(data = pm25, columns=c(5,6,8), title = "Comparing different models - PM2.5")
dev.off()

png(filename  = "nox.png",
    width  = 3000,
    height = 3000,
    res    = 300)
ggpairs(data = nox, columns=5:7, title = "Comparing different models - NOx")
dev.off()

png(filename  = "so2.png",
    width  = 3000,
    height = 3000,
    res    = 300)
ggpairs(data = so2, columns=5:7, title = "Comparing different models - SO2")
dev.off()


# Option 2: traditional R plots

# graphing function
# select pollutant: so2, nox, pm25
# select x margin (margin1): EASIUR.county(4), EASIUR.latlon(5), 
#                            AP2.value.2008(6), AP2.value.2005(7), AP2.value.2002(8), AP2.value.1999(9), 
#                            APEEP.value(7)
# select y margin (margin2) (same list as above)


pollutant <- "nox"
margin1 <- names(so2)[5]
margin2 <- names(so2)[6]

# plot using graphing function below
graph(pollutant, margin1, margin2, TRUE)


# print name of pollutant


# note: need to correct to ensure axes are the same

graph <- function(pollutant, margin1, margin2, log = FALSE){
  
  filename <- paste("plot ", pollutant, " for ", margin1, " and ", margin2, ".png", sep = "")
  
  if(pollutant == "pm25"){
    data <- pm25
  } else if (pollutant == "nox"){
    data <- nox
  } else if (pollutant == "so2"){
    data <- so2
  }
  
  x.col <- which(colnames(combined) == margin1)
  y.col <- which(colnames(combined) == margin2)
  
  max <- max(data[,x.col], data[,y.col])
  
  if (log == TRUE) {
  
    png(filename  = filename,
        width  = 3000,
        height = 3000,
        res    = 300)
   
    plot(data[,x.col], data[,y.col], xlab = margin1, ylab = margin2, log = "xy",
         asp = 1, main = pollutant)
   
    abline(0,1)
    dev.off()
    
  } else {
    
    png(filename  = filename,
        width  = 3000,
        height = 3000,
        res    = 300)
    
    plot(data[,x.col], data[,y.col], xlab = margin1, ylab = margin2,
         xlim = c(0,max),
         ylim = c(0,max), main = pollutant)
    
    abline(0,1)
    dev.off()
  }
}



### AVERAGES

# APEEP

APEEP.old <- APEEP.avg

APEEP.avg[,2] <- APEEP.avg[,2] / 0.907185  # convert to metric tons 
APEEP.avg[,2] <- APEEP.avg[,2] * 8.8 / 2   # use same VSL as EASIUR (simultaneously converts to $2010 dollars)

# AP2

AP2.2005.old <- AP2.2005.avg

AP2.2005.avg[,2] <- AP2.2005.avg[,2] / 0.907185  # convert to metric tons 
AP2.2005.avg[,2] <- AP2.2005.avg[,2] * 8.8 / 6   # use same VSL as EASIUR (simultaneously converts to $2010 dollars)

# EASIUR

EASIUR.avg

# EPA numbers

# 2009

Fann.2009 <- data.frame(pollutant = c("PM25", "SO2", "NOX"),
                        national.avg = c(460000, 82000, 15000))
  
Fann.2009$national.avg <- Fann.2009$national.avg * 8.8 / 6.2

# 2012

Fann.2012 <- data.frame(pollutant = c("PM25", "SO2", "NOX"),
                        national.avg = c(100000, 27000, 3700))

Fann.2012$national.avg <- Fann.2012$national.avg * 8.8 / 8.1


Fann.2012 <- data.frame(pollutant = c("PM25", "SO2", "NOX"),
                        national.avg = c(130000, 35000, 5200))

Fann.2012$national.avg <- Fann.2012$national.avg * 8.8 / 8.1

# NAS

NAS <- data.frame(pollutant = c("PM25", "SO2", "NOX"),
                        national.avg = c(32000, 13000, 2200))

NAS$national.avg <- NAS$national.avg * 8.8 / 8.1

