__author__ = 'nhorner'

import os
from tzwhere import tzwhere
import time
import sys
import re

t0 = time.time()

dir = os.getcwd()
print(dir)

tz = tzwhere.tzwhere(forceTZ=True, shapely=True)

# Some time zones are not matching in tzwhere; use state where obvious
eastern = ["CT", "FL", "GA", "IN", "KY", "MA", "MD", "ME", "MI", "NC", "NJ", "NY", "OH", "PA", "RI", "SC", "VA"]
central = ["AL", "LA", "MS", "TX", "WI"]
mountain = ["WY"]
pacific = ["CA", "NV", "OR", "WA"]

tzs = []

with open('plant_lat_lon.csv', 'r') as f:
    next(f)
    for line in f:
        raw = line.replace('"','').rstrip().split(",")
        orispl = raw[0]
        state = raw[1]
        lat = raw[2]
        lon = raw[3]
        sys.stdout.write("Processing: " + str(orispl) + '\n')
        if lat == "" or lon == "":
            timez = "None"
        else:
            timez = str(tz.tzNameAt(float(lat), float(lon)))
        if timez == "None":
            if state == "AK":
                timez = "APT"
            elif state == "HI":
                timez = "HPT"
            elif state in eastern:
                timez = "EPT"
            elif state in central:
                timez = "CPT"
            elif state in mountain:
                timez = "MPT"
            elif state in pacific:
                timez = "PPT"
        # Standardize codes
        if re.search("New_York", timez):
            timez = "EPT"
        elif re.search("Los_Angeles", timez):
            timez = "PPT"
        elif re.search("Chicago", timez):
            timez = "CPT"
        elif re.search("Anchorage", timez):
            timez = "APT"
        elif re.search("Boise", timez):
            timez = "MPT"
        elif re.search("Denver", timez):
            timez = "MPT"
        elif re.search("Detroit", timez):
            timez = "EPT"
        elif re.search("Godthab", timez):
            timez = "EPT" # error; this is Massachusetts
        elif re.search("Indianapolis", timez):
            timez = "EPT"
        elif re.search("Vevay", timez):
            timez = "EPT"
        elif re.search("Vincennes", timez):
            timez = "EPT"
        elif re.search("Petersburg", timez):
            timez = "CPT"
        elif re.search("Tell_City", timez):
            timez = "CPT"
        elif re.search("Juneau", timez):
            timez = "APT"
        elif re.search("Louisville", timez):
            timez = "EPT"
        elif re.search("Menominee", timez):
            timez = "CPT"
        elif re.search("Mexico_City", timez):
            timez = "CPT"  # Error; this is Texas
        elif re.search("Moncton", timez):
            timez = "EPT"  # New Brunswick ISO, Atlantic time; state is Maine
        elif re.search("Nome", timez):
            timez = "APT"
        elif re.search("Beulah", timez):
            timez = "MPT"
        elif re.search("North_Dakota", timez):
            timez = "CPT"
        elif re.search("Phoenix", timez):
            timez = "MPT"
        elif re.search("Sitka", timez):
            timez = "APT"
        elif re.search("Tijuana", timez):
            timez = "PPT"
        elif re.search("Honolulu", timez):
            timez = "HPT"

        tzs.append(str(orispl) + ',' + timez + '\n')

with open('plant_tz.csv', 'w') as outf:
    outf.write("orispl,tz\n")
    outf.writelines(tzs)

t1 = time.time()
print("Total time: " + str(t1 - t0))
